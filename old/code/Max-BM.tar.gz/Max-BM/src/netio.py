import numpy as np

def importSparseNetwork(file, thresh=0):
    f = open(file, "r")
    rows = f.readlines()
    f.close()
    rows = np.array([[int(val) for val in row.split(" ") if val.strip()!=""] for row in rows if row.strip()!=""])
    print file
    if not file == "../data/wordnet.txt":
        rows[:,:2] = rows[:,:2]-1   
    print np.shape(rows)
    if len(rows[0,:])>2 :
        I = np.sum((rows[(rows[:,2]>thresh),2]-thresh))
        print I
        edges = np.empty((I,2))
        ci = 0
        for row in rows :
            if row[2] > thresh :
                edges[ci:ci+(row[2]-thresh),:] = row[:2].reshape(1,2).repeat((row[2]-thresh),0)
                ci = ci+(row[2]-thresh)
    else :
        I = np.shape(rows)[0]
        print I
        edges = rows
    
    return edges
    

def importClassLabels(file) :
    f = open(file)
    rows = f.readlines()
    if len(rows) > 1 :
        classes = np.array([int(row.strip())-1 for row in rows if row.strip()!=""])
    else :
        row = rows[0]
        classes = np.array([int(val)-1 for val in row.split(" ") if val.strip()!=""])
    print len(classes)
    return classes