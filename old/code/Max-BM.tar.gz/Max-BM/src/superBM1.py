import numpy as np
import numexpr as ne
from matplotlib import pyplot as pp
from matplotlib import cm
from matplotlib.mlab import find
#~ from mpl_toolkits.axes_grid1.axes_divider import make_axes_area_auto_adjustable
from scipy.special import gammaln, psi, betaln, polygamma
from scipy.optimize import fmin_cg,fmin_ncg,fmin_bfgs
from random import sample
import netio
from copy import copy
import time
#~ import igraph as iG

### Classes of blockmodel: simple, single_down_multinomial, single_down_softmax, single_up, mixed_down

def expy(y):
    if np.sum(y>-500) < y.size:
        y += np.abs(np.max(y))
        #~ print y
    return np.exp(y)

def xlogy(x, y):
    #~ return x*(np.log(y+(y<=0)) - 10000*(y<=0))
    #~ return x*np.log(y+1e-200)
    return ne.evaluate("log(y+1e-200)*x")



class Supervised_Blockmodel(object):
    def __init__(self, data, params):
        self.init_time=time.time()
        #initialise data
        self.S = data["S"]
        self.R = data["R"]
        
        self.Ytrue = data["Ytrue"]
        
        #initialise params
        #~ self.K = params["K"]
        #~ self.alpha = np.ones(self.K)*params["alpha"]
        #~ self.disp = params["disp"]
        self.fp_tol = 1e-5
        self.convtol = 1e-6
        self.hyper_update_freq = 15
        self.maxiterations = params["maxiter"]
        self.miniterations = params["miniter"]
        self.initType = params["init"]
        
        #~ self.tnodes = tnodes
        #~ if params.has_key("N"):
        self.N = len(self.Ytrue)
        #~ else:
            #~ self.N = len(np.unique(np.append(self.S,self.R)))
        self.C = np.sum(np.unique(self.Ytrue)>=0)
        print np.unique(self.Ytrue)
        self.I = int(np.shape(self.S)[0])
        self.sidxs = dict((v,(data["S"]==v).nonzero()[0]) for v in xrange(self.N))
        self.ridxs = dict((v,(data["R"]==v).nonzero()[0]) for v in xrange(self.N))
        
    
    def updateZ(self):
        pass
    
    def update_eta(self):
        pass
    
    def initialiseZ(self):
        pass
    
    def update_alpha(self):
        pass
    def update_beta(self):
        pass
    
    def reset(self,params):
        #reset params
        self.reset_time=time.time()
        self.K = params["K"]
        self.alpha = np.ones(self.K)*params["alpha"]
        self.beta = params["beta"]
        self.disp = params["disp"]
        self.reg = params["reg"]
        self.initialiseZ()
    
    def calculateF1(self,conf) :
        p = np.diag(conf)/np.sum(conf,0)
        r = np.diag(conf)/np.sum(conf,1)
        p[np.isnan(p)] = 0
        r[np.isnan(r)] = 0
        f1 = 2*(p*r)/(p+r)
        f1[np.isnan(f1)] = 0
        return np.mean(f1)
    
    def calculateNMI(self,conf,N):
        #~ conf*=N
        Ni = np.sum(conf,0)
        Nj = np.sum(conf,1)
        #~ nmi=-2*np.sum(xlogy(conf,(conf*N)/(np.outer(Ni,Nj))))
        nmi=np.sum(xlogy(conf,conf/(np.dot(Nj[:,np.newaxis],Ni[np.newaxis,:])+1e-200)))
        nmi/=-((np.sum(xlogy(Ni,Ni))+np.sum(xlogy(Nj,Nj)))/2+1e-200)
        return nmi



    def validation(self) :
        #~ testidx = np.setdiff1d(np.arange(self.N),self.tnodes)
        self.p_train = np.sum(self.Ytrue[self.tnodes]==self.predictions[self.tnodes]) / float(len(self.tnodes))
        self.p_test = np.sum(self.Ytrue[self.testidx]==self.predictions[self.testidx]) / float(len(self.testidx))
        classes = np.unique(self.Ytrue)
        self.conf_tr = np.zeros((self.C,self.C))
        self.conf_te = np.zeros((self.C,self.C))
        for p in classes:
            for a in classes :
                self.conf_tr[p,a] = np.sum((self.Ytrue[self.tnodes]==a) & (self.predictions[self.tnodes]==p)) / float(len(self.tnodes))
                self.conf_te[p,a] = np.sum((self.Ytrue[self.testidx]==a) & (self.predictions[self.testidx]==p)) / float(len(self.testidx))
        self.f1_tr = self.calculateF1(self.conf_tr)
        self.f1_te = self.calculateF1(self.conf_te)
        self.nim_tr = self.calculateNMI(self.conf_tr,float(len(self.tnodes)))
        self.nim_te = self.calculateNMI(self.conf_te,float(len(self.testidx)))
    
    def getiorder(self):
        return np.append(self.tnodes,np.array(sample(range(self.N), self.N)))
    
    def calculateFinalELBO(self,lastt):
        self.calculateELBO(lastt)
    
    def infer(self):
        t=0
        self.ELBO = 1
        self.ELBOdiff = 1
        lastt = self.maxiterations
        #~ self.classify()
        #~ self.validation()
        self.fopt=0
        while t < self.maxiterations:
            iorder = self.getiorder()
            tot = 0
            for v in iorder :
                self.updateZ(v)
            if t%self.hyper_update_freq==self.hyper_update_freq-1:
                self.update_alpha()
                self.update_beta()
            if len(self.tnodes) > 0:
                #~ if t%self.hyper_update_freq==0:
                    self.update_eta()
            if self.disp:
                self.classify()
                self.validation()
            self.oldELBO = self.ELBO
            self.calculateELBO(t)
            t += 1
            if ((self.ELBOdiff < self.convtol)+(np.isnan(self.ELBO)))*(t>self.miniterations):
                lastt = t
                t = self.maxiterations
        self.disp=True
        self.classify()
        self.validation()
        self.calculateFinalELBO(lastt)
        return self.p_test, self.f1_te


class SglMem_DownStrm(Supervised_Blockmodel):
    def __init__(self, data, params):
        super(SglMem_DownStrm, self).__init__(data, params)
    
    def reset(self,params,tnodes):
        self.tnodes = tnodes
        super(SglMem_DownStrm, self).reset(params)
        
        self.eta = np.ones((self.C,self.K))/float(self.C)
        #~ ncs = [np.sum(self.Ytrue[self.tnodes]==c) for c in range(self.C)]
        #~ ncs /=(np.sum(ncs)+1e-200)
        #~ kind=0
        #~ for c in range(self.C):##########################################remove
            #~ self.eta[c,(c*self.K/self.C):((c+1)*self.K/self.C)] += 10
            #~ self.eta[c,(c*self.K/self.C):((c+1)*self.K/self.C)] += ncs[c]
            #~ ck=ncs[c]*(self.K-self.C)
            #~ self.eta[c,kind:kind+ck] += ncs[c]
            #~ kind+=ck
        self.hv = np.sum(self.eta,0)
        
        self.nv = np.zeros(self.K)        #initialise node-position co-occurance
        self.fv = np.zeros((self.N,self.K))     #count of sender-to node-position co-occurance (sum=outdegree)
        self.gv = np.zeros((self.N,self.K))     #count of receiver-from node-position co-occurance (sum=indegree)
        for i in xrange(self.I) :
            self.fv[self.S[i],:] += self.Z[self.R[i],:] 
            self.gv[self.R[i],:] += self.Z[self.S[i],:]
        self.c = np.dot(self.Z[self.S,:].T,self.Z[self.R,:])  
        self.nv = np.sum(self.Z,0)#needs an nvs and nvr!!
        #~ self.nvs = np.sum(self.Z[self.S,:],0)#needs an nvs and nvr!!
        #~ self.nvr = np.sum(self.Z[self.R,:],0)#needs an nvs and nvr!!
        self.ik = np.eye(self.K)
        
        #remove nodes with zero degree from training set
        #~ self.tnodes = np.setdiff1d(self.tnodes,np.int0(find(np.sum(self.fv+self.gv,1)==0)))
        self.train = np.int0(np.zeros(self.N))
        self.train[self.tnodes] = 1
        self.testidx = np.setdiff1d(np.arange(self.N),self.tnodes)
        self.fopt = 0
        
        self.m = np.zeros((self.C,self.K))
        for v in self.tnodes:
            self.m[self.Ytrue[v],:] += self.Z[v,:]
        self.n_tr = np.sum(self.m,0)
    
    def initialiseZ(self):
        #~ self.Z = np.ones((self.N,self.K))/float(self.K)
        self.Z = np.random.rand(self.N,self.K)
        
        ncs = [np.sum(self.Ytrue[self.tnodes]==c) for c in range(self.C)]
        ncs /=(np.sum(ncs)+1e-200)
        ck=[0]
        ck.extend(np.cumsum(ncs)*(self.K-self.C)+1)
        for v in xrange(self.N):
            if np.sum(self.tnodes==v):
                if self.initType == "balanced":
                    self.Z[v,(self.Ytrue[v]*self.K/self.C):((self.Ytrue[v]+1)*self.K/self.C)] += 10  ######should try different values
                if self.initType == "classbias":
                    self.Z[v,ck[self.Ytrue[v]]:ck[self.Ytrue[v]+1]] += 10  ######should try different values
            self.Z[v,:] /= np.sum(self.Z[v,:])
    
    def updateZ(self,v):
        #remove counts including current node v
        oldZi = np.copy(self.Z[v,:])
        newZi = np.copy(oldZi)
        #~ sridx = self.S[self.R==v]
        #~ rsidx = self.R[self.S==v]
        sridx = self.S[self.ridxs[v]]
        rsidx = self.R[self.sidxs[v]]
        v_tr = self.train[v]
        sumZsr = np.sum(self.Z[sridx,:],0)
        sumZrs = np.sum(self.Z[rsidx,:],0)
        self.c -= (sumZsr[:,np.newaxis]*oldZi + oldZi[:,np.newaxis]*sumZrs)
        self.fv[sridx,:] -= oldZi
        self.gv[rsidx,:] -= oldZi
        self.nv -= oldZi
        #~ self.nvs -= oldZi*len(self.sidxs[v])
        #~ self.nvr -= oldZi*len(self.ridxs[v])
        fvv = self.fv[v]
        gvv = self.gv[v]
        yv = self.Ytrue[v]
        nv = self.nv
        #~ nvs = self.nvs
        #~ nvr = self.nvr
        
        #calculate the conditional distribution z_v
        nvnv = self.nv[:,np.newaxis]*self.nv
        #~ nvnv = self.nvs[:,np.newaxis]*self.nvr
    
        cplusbeta = self.c+self.beta
        nvnvminuscplusbeta = nvnv - self.c + self.beta
        nvnv2beta = nvnv + self.beta + self.beta
        diagnvfv = np.diag(self.nv-fvv)
        #~ diagnvfv = np.diag(nvs-fvv)
        diagfv = np.diag(fvv)
        diagnv = np.diag(self.nv)
        #~ diagnv = np.diag(nvs)
        
        gammaln_cbeta = gammaln(cplusbeta)
        gammaln_nvnvcbeta = gammaln(nvnvminuscplusbeta)
        gammaln_nvnv2beta = gammaln(nvnv2beta)
        
        z_v = xlogy(1.,nv+self.alpha) 
        
        z_v += np.sum(gammaln(cplusbeta + fvv[np.newaxis,:] - diagfv) - gammaln_cbeta,1)
        z_v += np.sum(gammaln(nvnvminuscplusbeta + (nv-fvv)[np.newaxis,:] - diagnvfv) - gammaln_nvnvcbeta,1)
        #~ z_v += np.sum(gammaln(nvnvminuscplusbeta + (nvs-fvv)[np.newaxis,:] - diagnvfv) - gammaln_nvnvcbeta,1)
        z_v -= np.sum(gammaln(nvnv2beta + nv[np.newaxis,:] - diagnv) - gammaln_nvnv2beta,1)
        #~ z_v -= np.sum(gammaln(nvnv2beta + nvs[np.newaxis,:] - diagnv) - gammaln_nvnv2beta,1)
        
        z_v += np.sum(gammaln(cplusbeta + gvv[:,np.newaxis] + diagfv) - gammaln_cbeta,0)
        z_v += np.sum(gammaln(nvnvminuscplusbeta + (nv-gvv)[:,np.newaxis] +diagnvfv+ self.ik) - gammaln_nvnvcbeta,0)
        #~ z_v += np.sum(gammaln(nvnvminuscplusbeta + (nvr-gvv)[:,np.newaxis] +diagnvfv+ self.ik) - gammaln_nvnvcbeta,0)
        z_v -= np.sum(gammaln(nvnv2beta + nv[:,np.newaxis] + diagnv + self.ik) - gammaln_nvnv2beta,0)
        #~ z_v -= np.sum(gammaln(nvnv2beta + nvr[:,np.newaxis] + diagnv + self.ik) - gammaln_nvnv2beta,0)
        
        newZi = self.supervisedZupdate(v_tr,yv,newZi,z_v)
        
        #update the counts with the new distribution
        self.Z[v,:] = np.copy(newZi)
        self.c += (sumZsr[:,np.newaxis]*newZi + newZi[:,np.newaxis]*sumZrs)
        self.fv[sridx,:] += newZi
        self.gv[rsidx,:] += newZi
        self.nv += newZi
        #~ self.nvs += newZi*len(self.sidxs[v])
        #~ self.nvr += newZi*len(self.ridxs[v])
    
    def supervisedZupdate(self,v_tr,yv,newZi,z_v):
        if v_tr:
            self.m[yv,:] -= newZi
            self.n_tr -= newZi
        
        newZi = z_v + xlogy(v_tr,(self.m[yv,:]+self.eta[yv,:])/(self.n_tr+self.hv))
        newZi = expy(newZi)
        newZi /= np.sum(newZi)
        if v_tr:
            self.m[yv,:] += newZi
            self.n_tr += newZi
        return newZi
    
    
    def update_alpha(self) :
        N = self.N
        alpha_new = self.alpha
        Z = self.Z
        diff=1
        i=0
        while diff>1e-6:
            alpha=alpha_new
            sum_alpha = np.sum(alpha)
            alpha_new = alpha*(np.sum(psi(Z+alpha[np.newaxis,:]),0) - N*psi(alpha))/(N*psi(1 + sum_alpha) - N*psi(sum_alpha))
            diff = np.sum(np.abs(alpha_new-alpha))/(self.K)
            #~ print diff
            #~ print alpha
            i+=1
            if i>1000:
                diff=0
        #~ print alpha
        self.alpha = alpha_new
    
    #~ def update_alpha(self) :
        #~ self.alpha *= (psi(self.nv+self.alpha)-psi(self.alpha))/(psi(np.sum(self.nv+self.alpha)) - psi(np.sum(self.alpha)))
    

    def classify(self) :
        phi = (self.m + self.eta)/(self.n_tr + np.sum(self.eta,0))[np.newaxis,:]
        self.probs = np.dot(self.Z, phi.T)
        self.predictions = self.probs.argmax(1)
    
    
    def calculateELBO(self,t):
        
        self.ELBO = np.sum(gammaln(self.m+self.eta))-np.sum(gammaln(np.sum(self.m,0)+np.sum(self.eta,0)))
        self.ELBO += np.sum(gammaln(self.nv+self.alpha))-gammaln(self.N+np.sum(self.alpha))
        self.ELBO += gammaln(np.sum(self.alpha))-np.sum(gammaln(self.alpha))
        self.ELBO += np.sum(betaln(self.c+self.beta,np.outer(self.nv,self.nv)-self.c+self.beta))-self.K*self.K*betaln(self.beta,self.beta)
        self.ELBO -= np.sum(xlogy(self.Z,self.Z))
        
        self.ELBOdiff = np.abs((self.ELBO-self.oldELBO)/self.oldELBO)
        update="***"
        if self.disp:
            #~ print "%i: f1=%.2f(%.2f) acc=%.2f(%.2f)  ELBO = %f  ELBO diff = %f " % (t,self.f1_tr,self.f1_te,self.p_train, self.p_test, self.ELBO, self.ELBOdiff)
            print "%i: nmi=%.2f(%.2f) f1=%.2f(%.2f) acc=%.2f(%.2f)  ELBO = %f  ELBO diff = %f " % (t,self.nim_tr,self.nim_te, self.f1_tr,self.f1_te,self.p_train, self.p_test, self.ELBO, self.ELBOdiff)

class MultiMem_Sparse(Supervised_Blockmodel):
    def __init__(self, data, params):
        super(MultiMem_Sparse, self).__init__(data, params)
        self.etamaxiter = 1

    
    def reset(self,params,tnodes):
        super(MultiMem_Sparse, self).reset(params)
        #~ self.alpha = params["alpha"]
        self.expetaNs = np.ones((self.K,self.C))
        self.expetaNr = np.ones((self.K,self.C))
        self.alpha = np.ones((self.K,self.K))*params["alpha"]
        self.beta = np.ones(self.N)*params["beta"]
        self.nv = np.empty(self.N,dtype=int)        #initialise node degree
        self.fv = np.zeros((self.N,self.K))     #count of sender position-node co-occurance 
        self.gv = np.zeros((self.N,self.K))     #count of receiver position-node co-occurance 
        
        for v in range(self.N):
            self.nv[v] = len(self.sidxs[v])+len(self.ridxs[v])
            self.fv[v,:] = np.sum(np.sum(self.Z[self.sidxs[v],:],0),1)
            self.gv[v,:] = np.sum(np.sum(self.Z[self.ridxs[v],:],0),0)
        ###insert intial conditions
        self.eta = np.random.randn(self.K,self.C) 
        ncs = [np.sum(self.Ytrue[tnodes]==c) for c in range(self.C)]
        ncs /=(np.sum(ncs)+1e-200)
        ck=[0]
        ck.extend(np.cumsum(ncs)*(self.K-self.C)+1)
        for c in range(self.C):
            if self.initType == "balanced":
                self.eta[(c*self.K/self.C):((c+1)*self.K/self.C),c] += 10
            if self.initType == "classbias":
                self.eta[ck[c]:ck[c+1],c] += 10
        
        #~ self.sum_fv = np.sum(self.fv,0)+self.N*self.beta
        #~ self.sum_gv = np.sum(self.gv,0)+self.N*self.beta
        self.sum_fv = np.sum(self.fv,0)+np.sum(self.beta)
        self.sum_gv = np.sum(self.gv,0)+np.sum(self.beta)
        self.c = sum(self.Z,0)            #count of component pairs
    
        #remove nodes with zero degree from training set
        for v in range(self.N) :
            if self.nv[v] == 0 :
                tnodes = np.setdiff1d(tnodes,np.array([v]))
        self.tnodes = tnodes
        self.train = np.int0(np.zeros(self.N))
        self.train[self.tnodes] = 1
        self.train = dict(enumerate(self.train))
        #~ self.train = dict((k,1) for k in range(N)enumerate(self.tnodes) if v
        self.testidx = np.setdiff1d(np.arange(self.N),self.tnodes)
        
        #~ for v in self.tnodes:##############remove
            #~ c = self.Ytrue[v]
            #~ self.Z[self.sidxs[v],(c*self.K/self.C):((c+1)*self.K/self.C),:] += 10
            #~ self.Z[self.ridxs[v],:,(c*self.K/self.C):((c+1)*self.K/self.C)] += 10
        #~ self.Z/=np.sum(np.sum(self.Z,2),1)[:,np.newaxis,np.newaxis]
        #~ self.Z1 = np.sum(self.Z,2)
        #~ self.Z2 = np.sum(self.Z,1)
        
        if self.__class__ in [MultiMem_Sparse,MultiMem_Sparse_Dir]:
            self.getnormh()
        
    def initialiseZ(self):
        self.Z = np.ones((self.I,self.K,self.K))/float(self.K*self.K)
        self.Z1 = np.sum(self.Z,2)
        self.Z2 = np.sum(self.Z,1)
    
    def getiorder(self):
        return np.append(self.tnodes,np.array(sample(range(self.I), self.I)))
    
    def updateZ(self,i):
        #remove counts including current node v
        z1 = self.Z1[i,:]
        z2 = self.Z2[i,:]
        self.c += -self.Z[i,:,:]
        si = self.S[i]
        ri = self.R[i]
        self.fv[si,:] += -z1
        self.gv[ri,:] += -z2
        self.sum_fv += -z1
        self.sum_gv += -z2
        s_tr = self.train[si]
        r_tr = self.train[ri]
        
        ys = self.Ytrue[si]
        yr = self.Ytrue[ri]
        
        expetaNs = self.expetaNs
        expetaNsy = 1
        expetaNr = self.expetaNr
        expetaNry = 1
        
        #calculate the conditional distribution z_v
        if s_tr:
            expetaNs = self.exp_etaNv[self.nv[si]]
            expetaNsy = expetaNs[:,ys:ys+1]
        if r_tr:
            expetaNr = self.exp_etaNv[self.nv[ri]]
            expetaNry = expetaNr[:,yr:yr+1].T
        
        z_v = (self.c+self.alpha)*np.dot((self.fv[si:si+1,:]+self.gv[si:si+1,:]+self.beta[si]).T,(self.fv[ri:ri+1,:]+self.gv[ri:ri+1,:]+self.beta[ri])) 
        z_v /= (np.dot((self.sum_fv+self.sum_gv)[:,np.newaxis],(self.sum_fv+self.sum_gv)[np.newaxis,:]) + np.eye(self.K))
        z_v *= np.dot(expetaNsy,expetaNry)
        
        
        fp = 1
        newZi = np.copy(self.Z[i,:,:])
        hnorm_si = self.hnorm[si]
        hnorm_ri = self.hnorm[ri]
        while fp > self.fp_tol: 
            oldZi = np.copy(newZi)
            
            hsdotz = np.sum(hnorm_si)
            hnorm_si /= (s_tr*np.dot(z1,expetaNs) + (1-s_tr)*1.)
            hs = s_tr*np.sum(expetaNs * hnorm_si, 1)
            
            hrdotz = np.sum(hnorm_ri)
            hnorm_ri /= (r_tr*np.dot(z2,expetaNr) + (1-r_tr)*1.)
            hr = r_tr*np.sum(expetaNr * hnorm_ri, 1)
            
            newZi = z_v * np.exp(-((hs/hsdotz)[:,np.newaxis]+(hr/hrdotz)[np.newaxis,:]))
            newZi /= np.sum(newZi)
            
            z1 = np.sum(newZi,1)
            z2 = np.sum(newZi,0)
            
            hnorm_si *= (s_tr*np.dot(z1,expetaNs) + (1-s_tr)*1.)
            hnorm_ri *= (r_tr*np.dot(z2,expetaNr) + (1-r_tr)*1.)
            
            fp = np.sum(np.abs(oldZi - newZi))/(self.K*self.K)
        
        self.hnorm[si] = hnorm_si
        self.hnorm[ri] = hnorm_ri
        
        
        self.Z1[i,:] = z1
        self.Z2[i,:] = z2
        
        #update the counts with the new distribution
        self.Z[i,:,:] = newZi
        self.c += newZi
        self.fv[si,:] += z1
        self.gv[ri,:] += z2
        self.sum_fv += z1
        self.sum_gv += z2
    
    
    def getnormh(self):
        self.hnorm = np.empty((self.N,self.C))
        nv = self.nv
        exp_etaNv = [np.exp(self.eta/float(d)) for d in range(np.max(nv)+1)]
        sidxs=self.sidxs
        ridxs=self.ridxs
        for v in xrange(self.N):
            expetaN = exp_etaNv[nv[v]]
            
            sidx = sidxs[v]
            ridx = ridxs[v]
            self.hnorm[v,:] = (np.prod(np.dot(self.Z1[sidx,:],expetaN), 0) * np.prod(np.dot(self.Z2[ridx,:],expetaN), 0))
        self.exp_etaNv = exp_etaNv
    
    def update_alpha(self) :
        I = self.I
        alpha_new = self.alpha
        Z = self.Z
        diff=1
        i=0
        while diff>1e-6:
            alpha=alpha_new
            sum_alpha = np.sum(alpha)
            alpha_new = alpha*(np.sum(psi(Z+alpha[np.newaxis,:,:]),0) - I*psi(alpha))/(I*psi(1 + sum_alpha) - I*psi(sum_alpha))
            diff = np.sum(np.abs(alpha_new-alpha))/(self.K*self.K)
            i+=1
            if i>100:
                diff=0
        self.alpha = alpha_new
    
    
    #~ def update_beta(self) :
        #~ iv = self.fv+self.gv
        #~ self.sum_fv -= np.sum(self.beta)
        #~ self.sum_gv -= np.sum(self.beta)
        #~ self.beta *= np.sum(psi(iv+self.beta[:,np.newaxis])-psi(self.beta[:,np.newaxis]),1)/np.sum(psi(np.sum(iv+self.beta[:,np.newaxis],0)) - psi(np.sum(self.beta)))
        #~ self.sum_fv += np.sum(self.beta)
        #~ self.sum_gv += np.sum(self.beta)
        #~ print self.beta

    
    def update_eta(self):
        Z_hat = np.empty((self.N,self.K))
        z1 = self.Z1
        z2 = self.Z2
        S = self.S
        R = self.R
        nv = self.nv
        Y = self.Ytrue
        
        sidxs=self.sidxs
        ridxs=self.ridxs
        eta_prime = np.zeros((self.K,self.C))
        for v in self.tnodes : 
            nvv = float(nv[v])#.view(float)  
            #~ Z_hat[v,:] = (np.sum(z1[S==v,:],0) + np.sum(z2[R==v,:],0)) / nvv
            Z_hat[v,:] = (np.sum(z1[sidxs[v],:],0) + np.sum(z2[ridxs[v],:],0)) / nvv
            eta_prime[:,Y[v]] += Z_hat[v,:]
        
        self.eta_prime=eta_prime
        
        eta = self.eta.reshape(self.eta.size)
        
        eta, self.fopt, func_calls, grad_calls, warnflag = fmin_cg(self.L_eta, eta, self.L_eta_prime, args=(Z_hat, z1, z2), maxiter=self.etamaxiter, disp=0,full_output=1)
        
        self.eta = eta.reshape(self.K, self.C)
        self.getnormh()
        #~ self.etamaxiter += 1
        self.etamaxiter = np.min([30,self.etamaxiter+1])

    
    def L_eta(self, eta, Z_hat, z1, z2) :
        
        L_eta = 0
        eta = eta.reshape(self.K, self.C)
        nv = self.nv
        Y = self.Ytrue
        S = self.S
        R = self.R
        
        exp_etaNv = [np.exp(eta/float(d)) for d in range(np.max(nv)+1)]
        sidxs=self.sidxs
        ridxs=self.ridxs
        for v in self.tnodes : 
            #~ expetaN = np.exp(eta/nv[v])#.view(float))
            expetaN = exp_etaNv[nv[v]]
            L_eta += np.dot(Z_hat[v,:],eta[:,Y[v]])
            #~ L_eta += -xlogy(1.0,np.sum(np.prod(np.dot(z1[(S==v),:],expetaN), 0) * np.prod(np.dot(z2[(R==v),:],expetaN), 0)))
            L_eta += -xlogy(1.0,np.sum(np.prod(np.dot(z1[sidxs[v],:],expetaN), 0) * np.prod(np.dot(z2[ridxs[v],:],expetaN), 0)))
        #~ return -L_eta
        return -(L_eta - np.sum(eta*eta*self.reg/2.))
        

    def L_eta_prime(self, eta, Z_hat, z1, z2) :
        
        eta = eta.reshape(self.K, self.C)
        nv = self.nv.view(int)
        #~ Y = self.Ytrue
        S = self.S
        R = self.R
        K = self.K
        C = self.C
        
        L_eta_prime = np.zeros((self.K,self.C))
        
        exp_etaNv = [np.exp(eta/float(d)) for d in range(np.max(nv)+1)]
        sidxs=self.sidxs
        ridxs=self.ridxs
        for v in self.tnodes :
            nvv = nv[v]
            exp_etaN = exp_etaNv[nvv]
            
            
            #~ sidx = (S==v)
            #~ ridx = (R==v)
            sidx = sidxs[v]
            ridx = ridxs[v]
            z1s = z1[sidx,:]
            z2r = z2[ridx,:]
            
            #c_level dims: 1 x C
            #~ c_level = np.prod(np.dot(z1[sidx,:],exp_etaN), 0) * np.prod(np.dot(z2[ridx,:],exp_etaN), 0)#u
            c_level = np.prod(np.dot(z1s,exp_etaN), 0) * np.prod(np.dot(z2r,exp_etaN), 0)#u
            c_level /= np.sum(c_level)#v
            
            #this_k_levels dims: ns x k2 x C
            #~ this_k_levels = z1[sidx,:][:,:,np.newaxis] * exp_etaN#w
            this_k_levels = z1s[:,:,np.newaxis] * exp_etaN#w
            this_k_levels /= (nvv * np.sum(this_k_levels,1)[:,np.newaxis,:])#x
            #~ this_k_levelr = z2[ridx,:][:,:,np.newaxis] * exp_etaN#w
            this_k_levelr = z2r[:,:,np.newaxis] * exp_etaN#w
            this_k_levelr /= (nvv * np.sum(this_k_levelr,1)[:,np.newaxis,:])#x
            
            L_eta_prime += -c_level.reshape(1,C) * (np.sum(this_k_levels,0) + np.sum(this_k_levelr,0))
        L_eta_prime -= self.reg*eta
            
        return -(self.eta_prime+L_eta_prime).reshape(L_eta_prime.size)
        
        

    def classify(self) :
        probs = np.empty((self.N,self.C))
        z1 = self.Z1
        z2 = self.Z2
        S = self.S
        R = self.R
        nv = self.nv
        eta = self.eta
        sidxs = self.sidxs
        ridxs = self.ridxs
        
        for v in range(self.N) :
            z_hat = (np.sum(z1[sidxs[v],:],0) + np.sum(z2[ridxs[v],:],0)) / float(nv[v])
            probs[v,:] = np.exp(np.dot(z_hat, eta))
            probs[v,:] /= np.sum(probs[v,:])
        self.probs = probs
        self.predictions = probs.argmax(1)
        
    
    def calculateELBO(self,t):
        self.ELBO = -self.fopt + np.sum(self.eta*self.eta*self.reg/2.)
        self.ELBO += gammaln(np.sum(self.alpha)) - np.sum(gammaln(self.alpha))
        self.ELBO += np.sum(gammaln(self.c+self.alpha)) - gammaln(np.sum(self.c+self.alpha))
        
        self.ELBO += self.K*(gammaln(np.sum(self.beta)) - np.sum(gammaln(self.beta)))
        self.ELBO += np.sum(gammaln(self.fv+self.gv+self.beta[:,np.newaxis])) - np.sum(gammaln(np.sum(self.fv+self.gv+self.beta[:,np.newaxis],0)))
        
        self.ELBO -= np.sum(xlogy(self.Z,self.Z))
        
        self.ELBOdiff = np.abs((self.ELBO-self.oldELBO)/self.oldELBO)
        update="***"
        if self.disp:
            #~ print "%i: f1=%.2f(%.2f) acc=%.2f(%.2f)  ELBO = %f  ELBO diff = %f " % (t,self.f1_tr,self.f1_te,self.p_train, self.p_test, self.ELBO, self.ELBOdiff)
            print "%i: nmi=%.2f(%.2f) f1=%.2f(%.2f) acc=%.2f(%.2f)  ELBO = %f  ELBO diff = %f " % (t,self.nim_tr,self.nim_te, self.f1_tr,self.f1_te,self.p_train, self.p_test, self.ELBO, self.ELBOdiff)


class MultiMem_Sparse_Dir(MultiMem_Sparse):
        
    
    def updateZ(self,i):
        #remove counts including current node v
        z1 = self.Z1[i,:]
        z2 = self.Z2[i,:]
        self.c += -self.Z[i,:,:]
        si = self.S[i]
        ri = self.R[i]
        self.fv[si,:] += -z1
        self.gv[ri,:] += -z2
        self.sum_fv += -z1
        self.sum_gv += -z2
        s_tr = self.train[si]
        r_tr = self.train[ri]
        
        ys = self.Ytrue[si]
        yr = self.Ytrue[ri]
        
        expetaNs = self.expetaNs
        expetaNsy = 1
        expetaNr = self.expetaNr
        expetaNry = 1
        
        #calculate the conditional distribution z_v
        if s_tr:
            expetaNs = self.exp_etaNv[self.nv[si]]
            expetaNsy = expetaNs[:,ys:ys+1]
        if r_tr:
            expetaNr = self.exp_etaNv[self.nv[ri]]
            expetaNry = expetaNr[:,yr:yr+1].T
        
        z_v = (self.c+self.alpha)*np.dot((self.fv[si:si+1,:]+self.beta[si]).T,(self.gv[ri:ri+1,:]+self.beta[ri])) 
        z_v /= (np.dot((self.sum_fv)[:,np.newaxis],(self.sum_gv)[np.newaxis,:]) + np.eye(self.K))
        z_v *= np.dot(expetaNsy,expetaNry)
        
        
        fp = 1
        newZi = np.copy(self.Z[i,:,:])
        hnorm_si = self.hnorm[si]
        hnorm_ri = self.hnorm[ri]
        while fp > self.fp_tol: 
            oldZi = np.copy(newZi)
            
            hsdotz = np.sum(hnorm_si)
            hnorm_si /= (s_tr*np.dot(z1,expetaNs) + (1-s_tr)*1.)
            hs = s_tr*np.sum(expetaNs * hnorm_si, 1)
            
            hrdotz = np.sum(hnorm_ri)
            hnorm_ri /= (r_tr*np.dot(z2,expetaNr) + (1-r_tr)*1.)
            hr = r_tr*np.sum(expetaNr * hnorm_ri, 1)
            
            newZi = z_v * np.exp(-((hs/hsdotz)[:,np.newaxis]+(hr/hrdotz)[np.newaxis,:]))
            newZi /= np.sum(newZi)
            
            z1 = np.sum(newZi,1)
            z2 = np.sum(newZi,0)
            
            hnorm_si *= (s_tr*np.dot(z1,expetaNs) + (1-s_tr)*1.)
            hnorm_ri *= (r_tr*np.dot(z2,expetaNr) + (1-r_tr)*1.)
            
            fp = np.sum(np.abs(oldZi - newZi))/(self.K*self.K)
        
        self.hnorm[si] = hnorm_si
        self.hnorm[ri] = hnorm_ri
        
        
        self.Z1[i,:] = z1
        self.Z2[i,:] = z2
        
        #update the counts with the new distribution
        self.Z[i,:,:] = newZi
        self.c += newZi
        self.fv[si,:] += z1
        self.gv[ri,:] += z2
        self.sum_fv += z1
        self.sum_gv += z2
    
    
    
    def calculateELBO(self,t):
        self.ELBO = -self.fopt + np.sum(self.eta*self.eta*self.reg/2.)
        self.ELBO += gammaln(np.sum(self.alpha)) - np.sum(gammaln(self.alpha))
        self.ELBO += np.sum(gammaln(self.c+self.alpha)) - gammaln(np.sum(self.c+self.alpha))
        
        self.ELBO += self.K*(gammaln(np.sum(self.beta)) - np.sum(gammaln(self.beta)))
        self.ELBO += np.sum(gammaln(self.fv+self.beta[:,np.newaxis])) - np.sum(gammaln(np.sum(self.fv+self.beta[:,np.newaxis],0)))
        self.ELBO += np.sum(gammaln(self.gv+self.beta[:,np.newaxis])) - np.sum(gammaln(np.sum(self.gv+self.beta[:,np.newaxis],0)))
        
        self.ELBO -= np.sum(xlogy(self.Z,self.Z))
        
        self.ELBOdiff = np.abs((self.ELBO-self.oldELBO)/self.oldELBO)
        update="***"
        if self.disp:
            #~ print "%i: f1=%.2f(%.2f) acc=%.2f(%.2f)  ELBO = %f  ELBO diff = %f " % (t,self.f1_tr,self.f1_te,self.p_train, self.p_test, self.ELBO, self.ELBOdiff)
            print "%i: nmi=%.2f(%.2f) f1=%.2f(%.2f) acc=%.2f(%.2f)  ELBO = %f  ELBO diff = %f " % (t,self.nim_tr,self.nim_te, self.f1_tr,self.f1_te,self.p_train, self.p_test, self.ELBO, self.ELBOdiff)


class MultiMem_Sparse_Dir2k(MultiMem_Sparse):
    
    def reset(self,params,tnodes):
        super(MultiMem_Sparse_Dir2k, self).reset(params,tnodes)
        self.expetaNs = np.ones((2*self.K,self.C))
        self.expetaNr = np.ones((2*self.K,self.C))
        
        self.eta = np.random.randn(2*self.K,self.C) 
        ncs = [np.sum(self.Ytrue[tnodes]==c) for c in range(self.C)]
        ncs /=(np.sum(ncs)+1e-200)
        ck=[0]
        ck.extend(np.cumsum(ncs)*(self.K-self.C)+1)
        for c in range(self.C):
            if self.initType == "balanced":
                self.eta[ck[c]:ck[c+1],c] += 10
            if self.initType == "classbias":
                self.eta[self.K+ck[c]:self.K+ck[c+1],c] += 10
            #~ self.eta[(c*self.K/self.C):((c+1)*self.K/self.C),c] += 10
            #~ self.eta[(self.K+c*self.K/self.C):(self.K+(c+1)*self.K/self.C),c] += 10####
        
        self.getnormh()
    
    def updateZ(self,i):
        #remove counts including current node v
        z1 = self.Z1[i,:]
        z2 = self.Z2[i,:]
        self.c += -self.Z[i,:,:]
        si = self.S[i]
        ri = self.R[i]
        self.fv[si,:] += -z1
        self.gv[ri,:] += -z2
        self.sum_fv += -z1
        self.sum_gv += -z2
        s_tr = self.train[si]
        r_tr = self.train[ri]
        
        ys = self.Ytrue[si]
        yr = self.Ytrue[ri]
        
        expetaNs = self.expetaNs
        expetaNsy = 1
        expetaNr = self.expetaNr
        expetaNry = 1
        
        K=self.K
        
        #calculate the conditional distribution z_v
        if s_tr:
            expetaNs = self.exp_etaNv[self.nv[si]]
            expetaNsy = expetaNs[:K,ys:ys+1]
        if r_tr:
            expetaNr = self.exp_etaNv[self.nv[ri]]
            expetaNry = expetaNr[K:,yr:yr+1].T
        
        z_v = (self.c+self.alpha)*np.dot((self.fv[si:si+1,:]+self.beta[si]).T,(self.gv[ri:ri+1,:]+self.beta[ri])) 
        z_v /= (np.dot((self.sum_fv)[:,np.newaxis],(self.sum_gv)[np.newaxis,:]) + np.eye(self.K))
        z_v *= np.dot(expetaNsy,expetaNry)
        
        
        fp = 1
        newZi = np.copy(self.Z[i,:,:])
        hnorm_si = self.hnorm[si]
        hnorm_ri = self.hnorm[ri]
        while fp > self.fp_tol: 
            oldZi = np.copy(newZi)
            
            hsdotz = np.sum(hnorm_si)
            hnorm_si /= (s_tr*np.dot(z1,expetaNs[:K,:]) + (1-s_tr)*1.)
            hs = s_tr*np.sum(expetaNs[:K,:] * hnorm_si, 1)
            
            hrdotz = np.sum(hnorm_ri)
            hnorm_ri /= (r_tr*np.dot(z2,expetaNr[K:,:]) + (1-r_tr)*1.)
            hr = r_tr*np.sum(expetaNr[K:,:] * hnorm_ri, 1)
            
            newZi = z_v * np.exp(-((hs/hsdotz)[:,np.newaxis]+(hr/hrdotz)[np.newaxis,:]))
            newZi /= np.sum(newZi)
            
            z1 = np.sum(newZi,1)
            z2 = np.sum(newZi,0)
            
            hnorm_si *= (s_tr*np.dot(z1,expetaNs[:K,:]) + (1-s_tr)*1.)
            hnorm_ri *= (r_tr*np.dot(z2,expetaNr[K:,:]) + (1-r_tr)*1.)
            
            fp = np.sum(np.abs(oldZi - newZi))/(self.K*self.K)
        
        self.hnorm[si] = hnorm_si
        self.hnorm[ri] = hnorm_ri
        
        
        self.Z1[i,:] = z1
        self.Z2[i,:] = z2
        
        #update the counts with the new distribution
        self.Z[i,:,:] = newZi
        self.c += newZi
        self.fv[si,:] += z1
        self.gv[ri,:] += z2
        self.sum_fv += z1
        self.sum_gv += z2
    
    
    def getnormh(self):
        self.hnorm = np.empty((self.N,self.C))
        nv = self.nv
        exp_etaNv = [np.exp(self.eta/float(d)) for d in range(np.max(nv)+1)]
        sidxs=self.sidxs
        ridxs=self.ridxs
        K=self.K
        for v in xrange(self.N):
            expetaN = exp_etaNv[nv[v]]
            
            sidx = sidxs[v]
            ridx = ridxs[v]
            self.hnorm[v,:] = (np.prod(np.dot(self.Z1[sidx,:],expetaN[:K,:]), 0) * np.prod(np.dot(self.Z2[ridx,:],expetaN[K:,:]), 0))
        self.exp_etaNv = exp_etaNv

    
    def update_eta(self):
        Z_hat = np.empty((self.N,self.K*2))
        z1 = self.Z1
        z2 = self.Z2
        S = self.S
        R = self.R
        nv = self.nv
        Y = self.Ytrue
        K = self.K
        
        sidxs=self.sidxs
        ridxs=self.ridxs
        eta_prime = np.zeros((2*self.K,self.C))
        for v in self.tnodes : 
            nvv = float(nv[v])#.view(float)  
            Z_hat[v,:K] = np.sum(z1[sidxs[v],:],0) / nvv
            Z_hat[v,K:] = np.sum(z2[ridxs[v],:],0) / nvv
            eta_prime[:,Y[v]] += Z_hat[v,:]
        
        self.eta_prime=eta_prime
        
        eta = self.eta.reshape(self.eta.size)
        
        eta, self.fopt, func_calls, grad_calls, warnflag = fmin_cg(self.L_eta, eta, self.L_eta_prime, args=(Z_hat, z1, z2), maxiter=self.etamaxiter, disp=0,full_output=1)
        
        self.eta = eta.reshape(2*self.K, self.C)
        self.getnormh()
        #~ self.etamaxiter += 1
        self.etamaxiter = np.min([30,self.etamaxiter+1])

    
    def L_eta(self, eta, Z_hat, z1, z2) :
        
        L_eta = 0
        eta = eta.reshape(2*self.K, self.C)
        nv = self.nv
        Y = self.Ytrue
        S = self.S
        R = self.R
        K= self.K
        
        exp_etaNv = [np.exp(eta/float(d)) for d in range(np.max(nv)+1)]
        sidxs=self.sidxs
        ridxs=self.ridxs
        for v in self.tnodes : 
            expetaN = exp_etaNv[nv[v]]
            L_eta += np.dot(Z_hat[v,:],eta[:,Y[v]])
            L_eta += -xlogy(1.0,np.sum(np.prod(np.dot(z1[sidxs[v],:],expetaN[:K,:]), 0) * np.prod(np.dot(z2[ridxs[v],:],expetaN[K:,:]), 0)))
        return -(L_eta - np.sum(eta*eta*self.reg/2.))
        

    def L_eta_prime(self, eta, Z_hat, z1, z2) :
        
        eta = eta.reshape(2*self.K, self.C)
        nv = self.nv.view(int)
        #~ Y = self.Ytrue
        S = self.S
        R = self.R
        K = self.K
        C = self.C
        
        L_eta_prime = np.zeros((2*self.K,self.C))
        
        exp_etaNv = [np.exp(eta/float(d)) for d in range(np.max(nv)+1)]
        sidxs=self.sidxs
        ridxs=self.ridxs
        for v in self.tnodes :
            nvv = nv[v]
            exp_etaN = exp_etaNv[nvv]
            
            sidx = sidxs[v]
            ridx = ridxs[v]
            z1s = z1[sidx,:]
            z2r = z2[ridx,:]
            
            #c_level dims: 1 x C
            c_level = np.prod(np.dot(z1s,exp_etaN[:K,:]), 0) * np.prod(np.dot(z2r,exp_etaN[K:,:]), 0)#u
            c_level /= np.sum(c_level)#v
            
            #this_k_levels dims: ns x k2 x C
            this_k_levels = z1s[:,:,np.newaxis] * exp_etaN[:K,:]#w
            this_k_levels /= (nvv * np.sum(this_k_levels,1)[:,np.newaxis,:])#x
            this_k_levelr = z2r[:,:,np.newaxis] * exp_etaN[K:,:]#w
            this_k_levelr /= (nvv * np.sum(this_k_levelr,1)[:,np.newaxis,:])#x
            
            L_eta_prime[:K,:] += -c_level.reshape(1,C) * np.sum(this_k_levels,0) 
            L_eta_prime[K:,:] += -c_level.reshape(1,C) * np.sum(this_k_levelr,0)
        L_eta_prime -= self.reg*eta
            
        return -(self.eta_prime+L_eta_prime).reshape(L_eta_prime.size)
        
        

    def classify(self) :
        probs = np.empty((self.N,self.C))
        z1 = self.Z1
        z2 = self.Z2
        S = self.S
        R = self.R
        nv = self.nv
        eta = self.eta
        sidxs = self.sidxs
        ridxs = self.ridxs
        K=self.K
        z_hat = np.empty(2*K)
        for v in range(self.N) :
            z_hat[:K] = np.sum(z1[sidxs[v],:],0) / float(nv[v])
            z_hat[K:] = np.sum(z2[ridxs[v],:],0) / float(nv[v])
            probs[v,:] = np.exp(np.dot(z_hat, eta))
            probs[v,:] /= np.sum(probs[v,:])
        self.probs = probs
        self.predictions = probs.argmax(1)
    

class MED_SB(Supervised_Blockmodel):
    def __init__(self, data, params):
        super(MED_SB, self).__init__(data, params)
        from subprocess import call
        self.call = call
        self.svm = 0

    
    def reset(self,params,tnodes):
        super(MED_SB, self).reset(params)
        #~ self.alpha = params["alpha"]
        self.cost = params["reg"]
        #~ self.alpha = np.ones((self.K,self.K))*params["alpha"]
        self.alpha = np.ones((self.K,self.K))/(self.K*self.K)
        self.eyeK = np.eye(self.K)
        
        self.beta = params["beta"]
        self.nv = np.empty(self.N,dtype=int)        #initialise node degree
        self.fv = np.zeros((self.N,self.K))     #count of sender position-node co-occurance 
        self.gv = np.zeros((self.N,self.K))     #count of receiver position-node co-occurance 
        
        for v in range(self.N):
            self.nv[v] = len(self.sidxs[v])+len(self.ridxs[v])
            self.fv[v,:] = np.sum(np.sum(self.Z[self.sidxs[v],:],0),1)
            self.gv[v,:] = np.sum(np.sum(self.Z[self.ridxs[v],:],0),0)
        ###insert intial conditions
        self.mu = np.ones((len(tnodes),self.C))
        #~ self.eta = np.zeros((self.K,self.C))
        self.eta = np.random.randn(self.K,self.C) 
        ncs = [np.sum(self.Ytrue[tnodes]==c) for c in range(self.C)]
        ncs /=(np.sum(ncs)+1e-200)
        ck=[0]
        ck.extend(np.cumsum(ncs)*(self.K-self.C)+1)
        for c in range(self.C):
            if self.initType == "balanced":
                self.eta[(c*self.K/self.C):((c+1)*self.K/self.C),c] += 10
            #~ if self.initType == "classbias":
                #~ self.eta[ck[c]:ck[c+1],c] += 10
        
        
        self.sum_fv = np.sum(self.fv,0)+self.N*self.beta
        self.sum_gv = np.sum(self.gv,0)+self.N*self.beta
        self.c = sum(self.Z,0)            #count of component pairs
    
        #remove nodes with zero degree from training set
        #~ for v in range(self.N) :
            #~ if self.nv[v] == 0 :
                #~ tnodes = np.setdiff1d(tnodes,np.array([v]))
        self.tnodes = tnodes
        self.train = np.int0(np.zeros(self.N))
        self.train[self.tnodes] = 1
        self.train = dict(enumerate(self.train))
        self.testidx = np.setdiff1d(np.arange(self.N),self.tnodes)
        self.tnode_dict = dict([(tn,ti) for ti,tn in enumerate(tnodes)])
        
    
    def initialiseZ(self):
        self.Z = np.ones((self.I,self.K,self.K))/float(self.K*self.K)
        self.Z1 = np.sum(self.Z,2)
        self.Z2 = np.sum(self.Z,1)
    
    def getiorder(self):
        #~ return np.append(self.tnodes,np.array(sample(range(self.I), self.I)))
        return np.array(sample(range(self.I), self.I))
    
    def updateZ(self,i):
        #remove counts including current node v
        z1 = self.Z1[i,:]
        z2 = self.Z2[i,:]
        self.c -= self.Z[i,:,:]
        si = self.S[i]
        ri = self.R[i]
        self.fv[si,:] -= z1
        self.gv[ri,:] -= z2
        self.sum_fv -= z1
        self.sum_gv -= z2
        s_tr = self.train[si]
        r_tr = self.train[ri]
        mu = self.mu
        eta = self.eta
        ys = self.Ytrue[si]
        yr = self.Ytrue[ri]
        
        z_v = (self.c+self.alpha)*np.dot((self.fv[si:si+1,:]+self.gv[si:si+1,:]+self.beta).T,(self.fv[ri:ri+1,:]+self.gv[ri:ri+1,:]+self.beta)) 
        sum_fvgv = self.sum_fv+self.sum_gv
        z_v /= (np.dot(sum_fvgv[:,np.newaxis],sum_fvgv[np.newaxis,:]) + self.eyeK)
        if s_tr:
            mu_idx = mu[self.tnode_dict[si],:]
            zt = (mu_idx[np.newaxis,:,np.newaxis]*((eta.T)[ys,:] - (eta.T))).sum(1)/self.nv[si]
            z_v *= np.exp(zt-zt.max()).T
        if r_tr:
            mu_idx = mu[self.tnode_dict[ri],:]
            zt = (mu_idx[np.newaxis,:,np.newaxis]*((eta.T)[yr,:] - (eta.T))).sum(1)/self.nv[ri]
            z_v *= np.exp(zt-zt.max())
        
        z_v /=z_v.sum()
            
        z1 = z_v.sum(1)
        z2 = z_v.sum(0)
        
        self.Z1[i,:] = z1
        self.Z2[i,:] = z2
        
        #update the counts with the new distribution
        self.Z[i,:,:] = z_v
        self.c += z_v
        self.fv[si,:] += z1
        self.gv[ri,:] += z2
        self.sum_fv += z1
        self.sum_gv += z2
    
    
    
    def update_alpha(self) :
        pass
    
    
    def update_eta(self):
        #~ Z_hat = np.empty((self.N,self.K))
        z1 = self.Z1
        z2 = self.Z2
        nv = self.nv
        Y = self.Ytrue
        
        sidxs=self.sidxs
        ridxs=self.ridxs
        with open("z.dat","w") as f:
            for v in self.tnodes : 
                nvv = float(nv[v])
                if nvv>0:
                    Z_hat = (np.sum(z1[sidxs[v],:],0) + np.sum(z2[ridxs[v],:],0)) / nvv
                else: 
                    Z_hat = np.ones(self.K)/float(self.K)
                f.write("%i" % (Y[v]+1))
                for k in xrange(self.K):
                    f.write(" %i:%f" % ((k+1),Z_hat[k]))
                f.write("\n")
        self.call(["./svm_multiclass_learn", "-c", "%f" % self.cost, "-w", "0","-p","2", "-o", "1", "-v", "-1", "z.dat", "model"])
        
        
        with open("w.dat") as f:
            w = f.readlines()[0].strip(" \n")
            w = np.float64([wi for wi in w.split()])
        
        with open("mu.dat") as f:
            alphas = [[ai for ai in a.strip("\n").split()] for a in f.readlines()]
        
        mu = np.zeros(self.C*len(self.tnodes))
        for a in alphas:
            #~ mu[int(a[1])] = float(a[2])
            mu[int(a[1])] = float(a[2])
        
        w = w[1:]
        
        self.eta = w.reshape(self.C, self.K).T
        self.mu = mu.reshape(len(self.tnodes),self.C)
        

    def classify(self) :
        probs = np.empty((self.N,self.C))
        z1 = self.Z1
        z2 = self.Z2
        nv = self.nv
        sidxs = self.sidxs
        ridxs = self.ridxs
        Y = self.Ytrue
        Z_hat = np.empty((self.N,self.K))
        
        with open("z.dat","w") as f:
            for v in xrange(self.N) : 
                nvv = float(nv[v])
                #~ Z_hat = (np.sum(z1[sidxs[v],:],0) + np.sum(z2[ridxs[v],:],0)) / nvv
                Z_hat[v,:] = (np.sum(z1[sidxs[v],:],0) + np.sum(z2[ridxs[v],:],0)) / nvv
                f.write("%i" % (Y[v]+1))
                for k in xrange(self.K):
                    f.write(" %i:%f" % ((k+1),Z_hat[v,k]))
                f.write("\n")
        self.call(["./svm_multiclass_classify", "-v", "-1", "z.dat", "model", "predictions.dat"])
        self.z_hat = Z_hat
        with open("predictions.dat") as f:
            pred = np.int32([p.split()[0] for p in f.readlines()])
        
        self.predictions = pred-1
        #~ print sdfsdf
    
    def calculateELBO(self,t):
        #~ self.ELBO = -self.fopt + np.sum(self.eta*self.eta*self.reg/2.)
        self.ELBO = gammaln(np.sum(self.alpha)) - np.sum(gammaln(self.alpha))
        self.ELBO += np.sum(gammaln(self.c+self.alpha)) - gammaln(np.sum(self.c+self.alpha))
        
        #~ self.ELBO += self.K*(gammaln(np.sum(self.beta)) - np.sum(gammaln(self.beta)))
        self.ELBO += self.K*(gammaln(self.N*self.beta) - self.N*gammaln(self.beta))
        #~ self.ELBO += np.sum(gammaln(self.fv+self.gv+self.beta[:,np.newaxis])) - np.sum(gammaln(np.sum(self.fv+self.gv+self.beta[:,np.newaxis],0)))
        self.ELBO += np.sum(gammaln(self.fv+self.gv+self.beta)) - np.sum(gammaln(np.sum(self.fv+self.gv+self.beta,0)))
        
        self.ELBO -= np.sum(xlogy(self.Z,self.Z))
        
        self.ELBOdiff = np.abs((self.ELBO-self.oldELBO)/self.oldELBO)
        update="***"
        if self.disp:
            #~ print "%i: f1=%.2f(%.2f) acc=%.2f(%.2f)  ELBO = %f  ELBO diff = %f " % (t,self.f1_tr,self.f1_te,self.p_train, self.p_test, self.ELBO, self.ELBOdiff)
            #~ print "%i: nmi=%.2f(%.2f) f1=%.2f(%.2f) acc=%.2f(%.2f)  ELBO = %f  ELBO diff = %f " % (t,self.nim_tr,self.nim_te, self.f1_tr,self.f1_te,self.p_train, self.p_test, self.ELBO, self.ELBOdiff)
            print "Number of iterations:%i \tTraining Set Acc=%.2f \tTest Set Accuracy=%.2f" % (t,self.p_train, self.p_test)

    
    def infer(self):
        t=0
        self.ELBO = 1
        self.ELBOdiff = 1
        lastt = self.maxiterations
        #~ self.classify()
        #~ self.validation()
        self.fopt=0
        while t < self.maxiterations:
            iorder = self.getiorder()
            tot = 0
            for v in iorder :
                self.updateZ(v)
            #~ if t%self.hyper_update_freq==self.hyper_update_freq-1:
                #~ self.update_alpha()
                #~ self.update_beta()
            if len(self.tnodes) > 0:
                #~ if t%1==0:
                self.update_eta()
            if self.disp:
                self.classify()
                self.validation()
            self.oldELBO = self.ELBO
            self.calculateELBO(t)
            t += 1
            if ((self.ELBOdiff < self.convtol)+(np.isnan(self.ELBO)))*(t>50):
                lastt = t
                t = self.maxiterations
        self.disp=True
        if len(self.tnodes) > 0:
            self.update_eta()
        self.classify()
        self.validation()
        self.calculateFinalELBO(lastt)
        return self.p_test, self.f1_te


class Standard_Blockmodel(SglMem_DownStrm):
    
    def reset(self,params,tnodes):
        params["K"] = self.C
        super(Standard_Blockmodel, self).reset(params,tnodes)
    
    def initialiseZ(self):
        super(Standard_Blockmodel, self).initialiseZ()
        #~ self.Z = np.ones((self.N,self.K))/float(self.K)
        for v in self.tnodes:
            self.Z[v,:] = np.zeros(self.K)
            self.Z[v,self.Ytrue[v]] = 1
        #~ print np.append(self.Z,self.Ytrue[:,np.newaxis],1)
    
    def getiorder(self):
        #~ return sample(range(self.N), self.N)
        return sample(self.testidx, len(self.testidx))
    
    def supervisedZupdate(self,v_tr,yv,newZi,z_v):
        newZi = expy(z_v)
        newZi /= np.sum(newZi)
        return newZi
    
    def classify(self) :
        self.predictions = self.Z.argmax(1)
    
    def calculateELBO(self,t):
        self.ELBO = np.sum(gammaln(self.nv+self.alpha))-gammaln(self.N+np.sum(self.alpha))
        self.ELBO += -np.sum(gammaln(self.alpha))+gammaln(np.sum(self.alpha))
        self.ELBO += np.sum(betaln(self.c+self.beta,np.outer(self.nv,self.nv)-self.c+self.beta))
        self.ELBO -= np.sum(xlogy(self.Z,self.Z))
        
        #~ print + np.sum(gammaln(self.nv+self.alpha))-gammaln(self.N+np.sum(self.alpha))
        #~ print + -np.sum(gammaln(self.alpha))+gammaln(np.sum(self.alpha))
        #~ print + np.sum(betaln(self.c+self.beta,np.outer(self.nv,self.nv)-self.c+self.beta))
        #~ print - np.sum(xlogy(self.Z,self.Z))
        
        self.ELBOdiff = np.abs((self.ELBO-self.oldELBO)/self.oldELBO)
        update="***"
        if self.disp:
            #~ print "%i: f1=%.2f(%.2f) acc=%.2f(%.2f)  ELBO = %f  ELBO diff = %f " % (t,self.f1_tr,self.f1_te,self.p_train, self.p_test, self.ELBO, self.ELBOdiff)
            print "%i: nmi=%.2f(%.2f) f1=%.2f(%.2f) acc=%.2f(%.2f)  ELBO = %f  ELBO diff = %f " % (t,self.nim_tr,self.nim_te, self.f1_tr,self.f1_te,self.p_train, self.p_test, self.ELBO, self.ELBOdiff)
            
            

class Standard_Blockmodel_Gibbs(Standard_Blockmodel):
    
    def __init__(self, data, params):
        super(Standard_Blockmodel_Gibbs, self).__init__(data, params)
        self.burnin = self.miniterations
        self.miniterations = self.maxiterations
    
    def reset(self,params,tnodes):
        super(Standard_Blockmodel_Gibbs, self).reset(params,tnodes)
        #~ self.burnin = self.burnin_ref/len(self.testidx)
        #~ self.miniterations = self.maxiterations_ref/len(self.testidx)
        #~ self.maxiterations = self.maxiterations_ref/len(self.testidx)
    
    def getiorder(self):
        return sample(self.testidx, 1)
    
    def initialiseZ(self):
        #~ super(Standard_Blockmodel_Gibbs, self).initialiseZ()
        self.Z = np.ones((self.N,self.K))/float(self.K)
        for v in xrange(self.N):
            if v in self.tnodes:
                self.Z[v,:] = np.zeros(self.K)
                self.Z[v,self.Ytrue[v]] = 1
            else:
                self.Z[v,:] = np.random.multinomial(1, self.Z[v,:])
        self.Zcount = np.zeros(np.shape(self.Z))
        self.H = np.zeros(self.N)
    
    def updateZ(self,v,t):
        #remove counts including current node v
        oldZi = np.copy(self.Z[v,:])
        sridx = self.S[self.ridxs[v]]  #sender node ids to current v
        rsidx = self.R[self.sidxs[v]] # receiver node ids from current v
        self.fv[sridx,:] -= oldZi
        self.gv[rsidx,:] -= oldZi
        fvv = self.fv[v] #count of roles received from v
        gvv = self.gv[v] #count of roles sending to v
        
        self.c -= (gvv[:,np.newaxis]*oldZi + oldZi[:,np.newaxis]*fvv)
        self.nv -= oldZi
        nv = self.nv
        
        nvnv = self.nv[:,np.newaxis]*self.nv
    
        cplusbeta = self.c+self.beta
        nvnvminuscplusbeta = nvnv - self.c + self.beta
        nvnv2beta = nvnv + self.beta + self.beta
        diagnvfv = np.diag(self.nv-fvv)
        #~ diagnvfv = np.diag(nvs-fvv)
        diagfv = np.diag(fvv)
        diagnv = np.diag(self.nv)
        #~ diagnv = np.diag(nvs)
        
        gammaln_cbeta = gammaln(cplusbeta)
        gammaln_nvnvcbeta = gammaln(nvnvminuscplusbeta)
        gammaln_nvnv2beta = gammaln(nvnv2beta)
        
        
        z_v = np.sum(gammaln(cplusbeta + fvv[np.newaxis,:] - diagfv) - gammaln_cbeta,1)
        z_v += np.sum(gammaln(nvnvminuscplusbeta + (nv-fvv)[np.newaxis,:] - diagnvfv) - gammaln_nvnvcbeta,1)
        z_v -= np.sum(gammaln(nvnv2beta + nv[np.newaxis,:] - diagnv) - gammaln_nvnv2beta,1)
        
        z_v += np.sum(gammaln(cplusbeta + gvv[:,np.newaxis] + diagfv) - gammaln_cbeta,0)
        z_v += np.sum(gammaln(nvnvminuscplusbeta + (nv-gvv)[:,np.newaxis] +diagnvfv+ self.ik) - gammaln_nvnvcbeta,0)
        z_v -= np.sum(gammaln(nvnv2beta + nv[:,np.newaxis] + diagnv + self.ik) - gammaln_nvnv2beta,0)
        
        newZi = expy(z_v)
        newZi /= np.sum(newZi)
        
        if t > self.burnin:
            self.H[v] += np.sum(xlogy(newZi,newZi))
        newZi = np.random.multinomial(1, newZi)
        
        #update the counts with the new distribution
        self.Z[v,:] = np.copy(newZi)
        self.c += (gvv[:,np.newaxis]*newZi + newZi[:,np.newaxis]*fvv)
        self.fv[sridx,:] += newZi
        self.gv[rsidx,:] += newZi
        self.nv += newZi
        #~ print self.nv
    
    def supervisedZupdate(self,v_tr,yv,newZi,z_v):
        newZi = expy(z_v)
        newZi /= np.sum(newZi)
        newZi = np.random.multinomial(1, newZi)
        return newZi
    
    def calculateELBO(self,t):
        pass
        #~ super(Standard_Blockmodel_Gibbs, self).calculateELBO(t)
        #~ if t%1000==0:
            #~ print t, time.ctime(), self.p_test
        #~ if t > self.burnin:
            #~ self.Zcount += self.Z
            #~ self.H += np.sum(xlogy(self.Z,self.Z),1)
    
    def classify(self) :
        self.predictions = self.Zcount.argmax(1)
    
    def update_alpha(self):
        pass
    
    def infer(self):
        t=0
        self.ELBO = 1
        self.ELBOdiff = 1
        lastt = self.maxiterations
        self.classify()
        self.validation()
        self.fopt=0
        while t < self.maxiterations:
            v = self.getiorder()[0]
            #~ tot = 0
            #~ for v in iorder :
            self.updateZ(v,t)
            if t > self.burnin:
                self.Zcount[v,:] += self.Z[v,:]
            #~ if t%1000==0:
                #~ self.classify()
                #~ self.validation()
                #~ print t, time.ctime(), self.p_test
            t += 1
        self.disp=True
        self.classify()
        self.validation()
        self.calculateFinalELBO(t)
        return self.p_test, self.f1_te

gibbinit=50


class Experimenter:
    netfileDict = {
        "word" : "../data/wordnet.txt",
        "karate" : "../data/karate_edges.txt",
        "cora" : "../data/cora_edges.txt",
        "citeseer" : "../data/citeseer_edges.txt",
        "wedfed" : "../data/weddell_edges.txt",
        "wedmet" : "../data/weddell_edges.txt",
        "brown" : "../data/brown_edges.txt",
        "brownall" : "../data/brown_all_edges.txt",
        "news" : "../data/news_edges.txt",
        "news1" : "../data/news1S_edges.txt",
        "news1M" : "../data/news1M_edges.txt",
        "news1_7c" : "../data/news1S_7c_edges.txt",
        "news10" : "../data/news10S_edges.txt",
        "news10M" : "../data/news10M_edges.txt",
        "seafood" : "../data/seafoodweb-edges.txt",
        "seahabit" : "../data/seafoodweb-edges.txt",
        }
    classfileDict = {
        "word" : "../data/wordclass.txt",
        "karate" : "../data/karate_labels.txt",
        "cora" : "../data/cora_labels.txt",
        "citeseer" : "../data/citeseer_labels.txt",
        "wedfed" : "../data/weddell_feed.txt",
        "wedmet" : "../data/weddell_metab2.txt",
        "brown" : "../data/brown_labels.txt",
        "brownall" : "../data/brown_all_labels.txt",
        "news" : "../data/news_labels.txt",
        "news1" : "../data/news1S_classes.txt",
        "news1M" : "../data/news1M_classes.txt",
        "news1_7c" : "../data/news1S_7c_classes.txt",
        "news10" : "../data/news10S_classes.txt",
        "news10M" : "../data/news10M_classes.txt",
        "seafood" : "../data/seafoodweb-feeding.txt",
        "seahabit" : "../data/seafoodweb-habitat.txt",
        }
    
    modelDict = {
        "SBM" : Standard_Blockmodel,
        "SBMg" : Standard_Blockmodel_Gibbs,
        "SMD" : SglMem_DownStrm,
        "MMS" : MultiMem_Sparse,
        "MED" : MED_SB,
        "MMSD" : MultiMem_Sparse_Dir,
        "MMSD2" : MultiMem_Sparse_Dir2k,
        }
    
    def __init__(self, exp, model):
        self.exp = exp
        self.model = model
        self.netfile = self.netfileDict[exp]
        self.classfile = self.classfileDict[exp]
        self.data = {}
        self.data["Ytrue"] = netio.importClassLabels(self.classfile)
        edges = netio.importSparseNetwork(self.netfile)
        self.data["S"] = edges[:,0].astype(int)
        self.data["R"] = edges[:,1].astype(int)
        self.params = {
            "K" : 10,
            "alpha" : .1,
            "beta" : .1,
            "disp" : False,
            "maxiter" : 200,
            "miniter" : 50,
            "reg" : 0.01,
            "init" : "random",
            }
    
    def pickMINode(blockmodel):
        testidx = blockmodel.testidx
        #~ s= float(blockmodel.maxiterations - blockmodel.burnin)*len(testidx)*gibbinit
        z = blockmodel.Zcount
        sum_z= np.sum(z,1)
        z /= sum_z[:,np.newaxis]
        MI = -np.sum(xlogy(z,z),1) + blockmodel.H/sum_z
        nodeidx = np.argmax(MI[testidx])
        
        newNode = testidx[nodeidx]
        #~ print sum_z
        print time.ctime(), len(blockmodel.tnodes), newNode, np.min(MI[testidx]), np.max(MI[testidx]), blockmodel.p_test
        return newNode



    def pickMinMarginNode(blockmodel):
        testidx = blockmodel.testidx
        for v in blockmodel.testidx :
            if blockmodel.nv[v] == 0 :
                testidx = np.setdiff1d(testidx,np.array([v]))
        
        #tmpdir = os.environ["TMPDIR"]
        
        
        with open("predictions.dat") as f:
        #with open("%s/predictions.dat" % tmpdir) as f:
            pred = np.float64([p.split() for p in f.readlines()])
        
        pred = pred[testidx,:]
        diff = (pred[:,1:].max(1))[:,np.newaxis]-pred[:,1:]
        mindiff = [d[d!=0].min() for d in diff]
        nodeidx = np.argmin(mindiff)
        
        newNode = testidx[nodeidx]
        return newNode

    def pickRandomNode(blockmodel):
        testidx = blockmodel.testidx
        newNode = sample(testidx,1)[0]
        #~ print len(blockmodel.tnodes), newNode, blockmodel.Ytrue[newNode]
        return newNode

    def pickDegreeNode(blockmodel):
        nodeidx = np.argmax(blockmodel.nv[blockmodel.testidx])
        return blockmodel.testidx[nodeidx]
    
    
    selectionMethods={
        "random" : pickRandomNode,
        "degree" : pickDegreeNode,
        "minmar" : pickMinMarginNode,
        "mi" : pickMINode,
        }
    
    def runActiveExp(self,blockmodel=None,selectionMethod="random",nodefile=None,f1file=None,accfile=None,totalsteps=None,svm=0,startnodes=None):
        print time.ctime()
        s = time.time()
        if selectionMethod.__class__ == list:
            nodeorder = iter(np.int0(selectionMethod)).next
            pickNode = lambda(x):nodeorder()
            startnodes = [pickNode(1),pickNode(1)]
        else:
            pickNode = self.selectionMethods[selectionMethod]
        if not blockmodel:
            blockmodel = self.modelDict[self.model](self.data, self.params)
        if startnodes is None:
            train = np.zeros(blockmodel.N)
            for c in range(blockmodel.C) :
                nc = np.sum(blockmodel.Ytrue==c)
                #~ print c
                ncorder = np.array(sample(range(nc), 1))
                #~ ncorder = np.array(sample(range(nc), int(.5*nc)))
                cidx = find(blockmodel.Ytrue==c)
                trainidx = cidx[ncorder]
                train[trainidx] = 1
            tnodes = np.int0(find(train))
        else:
            tnodes = np.int0(startnodes)
        print "initial training set = ", tnodes
        blockmodel.reset(self.params,tnodes)
        blockmodel.svm=svm
        if self.model=="SBMg":
            z=np.zeros((blockmodel.N,blockmodel.K))
            h=np.zeros(blockmodel.N)
            for gi in xrange(gibbinit):
                if self.exp in ["seafood","seahabit"]:
                    blockmodel.N = 492
                    blockmodel.reset(self.params,blockmodel.tnodes)
                    blockmodel.N = 488
                    blockmodel.testidx = np.setdiff1d(np.arange(blockmodel.N),blockmodel.tnodes)
                else:
                    blockmodel.reset(self.params,blockmodel.tnodes)
                blockmodel.Zcount += z
                blockmodel.H += h
                blockmodel.disp = self.params["disp"]
                blockmodel.infer()
                z = blockmodel.Zcount
                h = blockmodel.H
        else:
            if self.exp in ["seafood","seahabit"]:
                #~ print blockmodel.N
                blockmodel.N = 488
                blockmodel.testidx = np.setdiff1d(np.arange(blockmodel.N),blockmodel.tnodes)
            blockmodel.infer()
        
        if nodefile is not None:
            for node in tnodes:
                nodefile.write("%i %i, " % (node,blockmodel.Ytrue[node]))
                nodefile.flush()
        if totalsteps is None:
            totalsteps=len(blockmodel.testidx)
        #~ costs = [1,4,9,16,25,36,49,64]
        costs = [64,49,36,25,16,9,4,1,81,100]
        #~ costs = [0.01,0.1,1,10,100,1000,10000]
        for v in xrange(totalsteps):
            if (len(blockmodel.tnodes) > 5) & (self.model=="MED"):
                try:
                    curr_scores=[]
                    tnode_order = sample(blockmodel.tnodes,len(blockmodel.tnodes))
                    for cost in costs:
                        xv_step = len(tnode_order)/5
                        xv_start = 0
                        p_test = 0
                        for xv in range(5):
                            blockmodel.testidx = np.array(tnode_order[xv_start:(xv_start+xv_step)])
                            xv_start+=xv_step
                            blockmodel.tnodes = np.setdiff1d(tnode_order,blockmodel.testidx)
                            #~ print blockmodel.testidx
                            #~ print blockmodel.tnodes
                            blockmodel.cost = cost
                            blockmodel.update_eta()
                            blockmodel.classify()
                            blockmodel.validation()
                            p_test+=blockmodel.p_test
                        curr_scores.append(p_test)
                    blockmodel.cost = costs[np.argmax(curr_scores)]
                except:
                    pass
                    #~ print "fail"
                blockmodel.tnodes = tnode_order
                blockmodel.testidx = np.setdiff1d(np.arange(blockmodel.N),blockmodel.tnodes)
                blockmodel.update_eta()
                blockmodel.classify()
                    #~ print curr_scores
                #~ print len(blockmodel.tnodes), blockmodel.cost, curr_scores
            newNode = pickNode(blockmodel)
            print "Stage:", len(blockmodel.tnodes), "\tNext node ID:", newNode, "\tNext node Class:", blockmodel.Ytrue[newNode]
            blockmodel.tnodes = np.append(blockmodel.tnodes,newNode)
            blockmodel.train[newNode] = 1
            blockmodel.testidx = np.setdiff1d(np.arange(blockmodel.N),blockmodel.tnodes)
            if self.model == "MED":
                blockmodel.tnode_dict[newNode] = len(blockmodel.tnodes)-1
            blockmodel.update_eta()
            if self.model=="SBMg":
                z=np.zeros(np.shape(z))
                h=np.zeros(len(h))
                for gi in xrange(gibbinit):
                    if self.exp in ["seafood","seahabit"]:
                        blockmodel.N = 492
                        blockmodel.reset(self.params,blockmodel.tnodes)
                        blockmodel.N = 488
                        blockmodel.testidx = np.setdiff1d(np.arange(blockmodel.N),blockmodel.tnodes)
                    else:
                        blockmodel.reset(self.params,blockmodel.tnodes)
                    blockmodel.Zcount += z
                    blockmodel.H += h
                    blockmodel.disp = self.params["disp"]
                    blockmodel.infer()
                    z = blockmodel.Zcount
                    h = blockmodel.H
            else:
                #~ print blockmodel.mu
                blockmodel.disp = self.params["disp"]
                #~ print blockmodel.tnode_dict.keys()
                blockmodel.infer()
            #~ print time.time()-s
            if nodefile is not None:
                #~ nodefile.write("%i " % newNode)
                nodefile.write("%i %i, " % (newNode,blockmodel.Ytrue[newNode]))
                nodefile.flush()
            if accfile is not None:
                accfile.write("%f " % blockmodel.p_test)
                accfile.flush()
            if f1file is not None:
                f1file.write("%f " % blockmodel.f1_te)
                f1file.flush()
            #~ print time.ctime()
        print time.ctime()
        print time.time()-s
        return blockmodel
    
    def runUnsupExp(self,blockmodel=None,reps=3,ts=0.5):
        if not blockmodel:
            blockmodel = self.modelDict[self.model](self.data, self.params)
        train = np.zeros(blockmodel.N)
        for c in range(blockmodel.C) :
            nc = np.sum(blockmodel.Ytrue==c)
            ncorder = np.array(sample(range(nc), nc))
            cidx = find(blockmodel.Ytrue==c)
            trainidx = cidx[ncorder[:(ts*nc)]]
            train[trainidx] = 1
        tnodes = np.int0(find(train))
        blockmodel.reset(self.params,tnodes)
        valid = np.zeros(blockmodel.N)
        for c in range(blockmodel.C) :
            nc = np.sum(blockmodel.Ytrue==c)
            cidx = np.intersect1d(find(blockmodel.Ytrue==c),blockmodel.testidx)
            valididx = np.array(sample(cidx, int(np.ceil(.1*nc))))
            #~ print valididx
            valid[valididx]=1
            #~ valididx = cidx[ncorder]
        #~ valididx = np.array(sample(blockmodel.testidx, int(blockmodel.N*.1)))
        valididx = np.int0(find(valid))
        bestf1 = 0
        times=0
        for r in range(reps):
            blockmodel.reset(self.params,[])
            blockmodel.infer()
            blockmodel.tnodes = tnodes
            blockmodel.testidx = np.setdiff1d(np.arange(blockmodel.N),tnodes)
            #~ print blockmodel.eta
            #~ for ei in range(10):
            blockmodel.etamaxiter = 2000
            blockmodel.update_eta()
            if self.model=="SMD":
                blockmodel.m = np.zeros((blockmodel.C,blockmodel.K))
                for v in blockmodel.tnodes:
                    blockmodel.m[blockmodel.Ytrue[v],:] += blockmodel.Z[v,:]
                blockmodel.n_tr = np.sum(blockmodel.m,0)
            blockmodel.classify()
            blockmodel.validation()
            blockmodel.calculateELBO(0)
            #~ print blockmodel.eta
            blockmodel.testidx = np.setdiff1d(blockmodel.testidx,valididx)
            blockmodel.tnodes = valididx
            blockmodel.validation()
            if blockmodel.f1_tr > bestf1:
                bestf1 = blockmodel.f1_tr
                acc = blockmodel.p_test
                f1 = blockmodel.f1_te
                acc_tr = blockmodel.p_train
                f1_tr = blockmodel.f1_tr
                bestBlockmodel = copy(blockmodel)
            print bestf1
            print time.time()-blockmodel.reset_time
            times+= time.time()-blockmodel.reset_time
            print " %f, %f, %f, %f" %(blockmodel.p_train, blockmodel.f1_tr, blockmodel.p_test, blockmodel.f1_te)
        bestBlockmodel.times = times/reps
        return bestBlockmodel
    
    def runExp(self,blockmodel=None,reps=3,ts=0.5):
        if not blockmodel:
            blockmodel = self.modelDict[self.model](self.data, self.params)
        train = np.zeros(blockmodel.N)
        for c in range(blockmodel.C) :
            nc = np.sum(blockmodel.Ytrue==c)
            ncorder = np.array(sample(range(nc), nc))
            cidx = find(blockmodel.Ytrue==c)
            trainidx = cidx[ncorder[:(ts*nc)]]
            train[trainidx] = 1
        tnodes = np.int0(find(train))
        blockmodel.reset(self.params,tnodes)
        valid = np.zeros(blockmodel.N)
        ncs = np.zeros(blockmodel.C)
        for c in range(blockmodel.C) :
            nc = np.sum(blockmodel.Ytrue==c)
            ncs[c]=nc
            cidx = np.intersect1d(find(blockmodel.Ytrue==c),blockmodel.testidx)
            valididx = np.array(sample(cidx, int(np.ceil(.1*nc))))
            print valididx
            valid[valididx]=1
            #~ valididx = cidx[ncorder]
        #~ valididx = np.array(sample(blockmodel.testidx, int(blockmodel.N*.1)))
        valididx = np.int0(find(valid))
        bestf1 = 0
        times=0
        self.params["ncs"]=ncs
        for r in range(reps):
            if self.exp in ["seafood","seahabit"]:
                blockmodel.N = 492
            blockmodel.reset(self.params,tnodes)
            if self.exp in ["seafood","seahabit"]:
                print blockmodel.N
                blockmodel.N = 488
                blockmodel.testidx = np.setdiff1d(np.arange(blockmodel.N),blockmodel.tnodes)
            blockmodel.infer()
            blockmodel.testidx = np.setdiff1d(blockmodel.testidx,valididx)
            blockmodel.tnodes = valididx
            blockmodel.validation()
            if blockmodel.f1_tr > bestf1:
                bestf1 = blockmodel.f1_tr
                acc = blockmodel.p_test
                f1 = blockmodel.f1_te
                acc_tr = blockmodel.p_train
                f1_tr = blockmodel.f1_tr
                bestBlockmodel = copy(blockmodel)
            print bestf1
            print time.time()-blockmodel.reset_time
            times+= time.time()-blockmodel.reset_time
            print " %f, %f, %f, %f" %(blockmodel.p_train, blockmodel.f1_tr, blockmodel.p_test, blockmodel.f1_te)
        bestBlockmodel.times = times/reps
        return bestBlockmodel
    
    
    def runSet(self,iterations=1,KList=[10],train_sizes=[.5],scoretext="",disp=False,reps=3):
        self.params["disp"] = disp
        scoretext = "%s_%s_%s.txt" %(scoretext,self.exp,self.model)
        blockmodel = self.modelDict[self.model](self.data, self.params)
        for c in range(blockmodel.C) :
            nc = np.sum(blockmodel.Ytrue==c)
            print "Size class %i: %i" %(c, nc)
        for i in xrange(iterations):
            for k in KList:
                self.params["K"] = k
                for ts in train_sizes :
                    blockmodel=self.runExp(blockmodel,reps,ts)
                    scorefile = open(scoretext, "a")
                            
                    scorefile.write("%i, %i, %.2f, %.4f, %.4f, %f, %.4f, %.4f, %.3f \n " % (i, k, ts, blockmodel.p_test, blockmodel.f1_te, blockmodel.ELBO,blockmodel.p_train,blockmodel.f1_tr,blockmodel.times))
                    scorefile.flush()
                    scorefile.close()

def exp1(exp,model,scoretext="",iterations=100,reps=3,maxiter=200,disp=False):
    e = Experimenter(exp,model)
    blockmodel = e.modelDict[e.model](e.data, e.params)
    c = blockmodel.C
    del blockmodel
    e.params["maxiter"]=maxiter
    KList=[c, c*2, c*3, c*4, c*5, c*6, c*7, c*8]
    #~ KList.reverse()
    e.runSet(iterations=iterations,KList=KList,scoretext="kexp"+scoretext,reps=reps,disp=disp)

def test():
    e = Experimenter("word","MMSD2")
    e.params["disp"]=True
    e.runExp(reps=1)


def exp_word_cora():
    exp1("word","SMD")
    exp1("word","MMS")
    exp1("word","MMS2k")
    exp1("cora","SMD")
    exp1("cora","MMS")
    exp1("cora","MMS2k")
    
    
def profile(model,no=0):
    import cProfile
    e = Experimenter("seafood",model)
    scoretext = "profile%i_%s_%s" %(no,e.exp,e.model)
    e.params["maxiter"]=50
    e.params["reg"]=50
    cProfile.runctx('e.runSet(KList=[24],scoretext="prof",disp=True,reps=1)',globals(),locals(),scoretext)

#~ yticklabels = ["Verb","Adverb","Pronoun","Noun","Adject"]
yticklabels = ["benthic","benthopelagic","demersal","land-based","pelagic"]
#~ yticklabels = ["primary","carniv","carn/nec","detriv","herb/det","omniv"]
#~ yticklabels = ["primary","detriv","herb/det","carniv","omniv","carn/det"]
#~ yticklabels = ["Neural Networks","Rule Learning","Reinforcement Learning","Probabilistic Methods","Theory","Genetic Algorithms","Case Based"]
#~ yticklabels = ["Adjective","Noun"]
yts=[]
for yt in yticklabels:
    for i in range(1):
        yts.append(yt)

#SMD
def plotroleadj(blockmodel,order=None,parts=None):
    pp.figure()
    cmap=pp.cm.bone_r
    c = np.dot(blockmodel.Z[blockmodel.S,:].T,blockmodel.Z[blockmodel.R,:])
    roleadj =np.round((c+blockmodel.beta)/(np.outer(blockmodel.nv,blockmodel.nv)+2*blockmodel.beta)*10000)/10000.
    phi = (blockmodel.m + blockmodel.eta)/(blockmodel.n_tr + np.sum(blockmodel.eta,0))[np.newaxis,:]
    o=np.argmax(phi,0)
    parts = np.arange(blockmodel.C)
    order = np.arange(blockmodel.K)
    ktot=0
    for cl in range(blockmodel.C):
        parts[cl]=np.sum(o==cl)
        order[ktot:ktot+parts[cl]]=np.arange(blockmodel.K)[o==cl][np.argsort(phi[cl,(o==cl)])]
        ktot+=parts[cl]
    print parts
    if order is not None:
        roleadj=roleadj[np.ix_(order,order)]
    pp.pcolor(roleadj[np.arange(len(roleadj)-1,-1,-1),:],cmap=cmap)
    yticklabels=yts
    xticklabels = copy(yticklabels)
    #~ xticklabels.reverse()
    #~ pp.xticks(np.arange(blockmodel.K)+.5,xticklabels,fontsize=14)#,rotation=55)
    #~ pp.yticks(np.arange(blockmodel.K)+.5,yticklabels,fontsize=14)#,rotation=55)
    print pp.xlim()[1]-(np.cumsum(parts)-parts/2.)
    pp.xticks((np.cumsum(parts)-parts/2.),xticklabels,fontsize=14,rotation=35)
    pp.yticks(pp.ylim()[1]-(np.cumsum(parts)-parts/2.),yticklabels,fontsize=14)#,rotation=55)
    if parts is not None:
        for part in np.cumsum(parts):
            pp.plot(pp.xlim(),(pp.xlim()[1]-(part,part)),"b--",lw=6)
            pp.plot((part,part),pp.ylim(),"b--",lw=6)
    pp.colorbar()
    print roleadj
    pp.show()

#MMS
def plotRoleDists(blockmodel,roles=None):
    if roles:
        roles = np.array(roles)-1
    else:
        roles=np.arange(blockmodel.K)
    m = np.zeros((blockmodel.C,blockmodel.K))
    Z = np.empty((blockmodel.N,blockmodel.K))
    S = blockmodel.S
    R = blockmodel.R
    z1 = blockmodel.Z1
    z2 = blockmodel.Z2
    Ytrue = blockmodel.Ytrue
    #~ nv = blockmodel.nv
    for v in range(blockmodel.N) : 
        #~ nvv = float(nv[v])#.view(float)  
        Z[v,:] = (np.sum(z1[S==v,:],0) + np.sum(z2[R==v,:],0)) #/ nvv
        #~ m[Ytrue[v],:] += Z[v,:]
    order = np.argsort(Ytrue)
    Z = Z[order]
    tots = np.empty((blockmodel.C,blockmodel.K))
    pp.ion()
    startclass=0
    for c in range(blockmodel.C):
        endclass = startclass+np.sum(Ytrue==c)
        tots[c,:] = np.sum(Z[startclass:endclass,:],0)
        startclass=endclass
    tots/=np.sum(tots,0)[np.newaxis,:]
    for k in roles:
        pp.figure()
        pp.bar(np.arange(blockmodel.C),tots[:,k])
        pp.title("Role %i" %(k+1),fontsize=35)
        pp.xticks(np.arange(blockmodel.C)+.2,yticklabels,fontsize=24,rotation=55)
        pp.yticks(np.arange(0,1.1,.1),np.arange(0,1.1,.1),fontsize=20)
        make_axes_area_auto_adjustable(pp.gca())
        pp.savefig("brown_role_%i.png" %(k+1))
    pp.close("all")

def plotMMS(blockmodel):
    #~ yticklabels = ("Verb","Adverb","Pronoun","Noun","Adjective")
    cmap=pp.cm.bone_r
    if blockmodel.N ==488:
        blockmodel.N = 492
    m = np.zeros((blockmodel.C,blockmodel.K))
    Z = np.empty((blockmodel.N,blockmodel.K))
    S = blockmodel.S
    R = blockmodel.R
    z1 = blockmodel.Z1
    z2 = blockmodel.Z2
    Ytrue = blockmodel.Ytrue
    #~ nv = blockmodel.nv
    for v in range(blockmodel.N) : 
        #~ nvv = float(nv[v])#.view(float)  
        Z[v,:] = (np.sum(z1[S==v,:],0) + np.sum(z2[R==v,:],0)) #/ nvv
        m[Ytrue[v],:] += Z[v,:]
    Z_hat = Z/(np.sum(Z,1)+1e-200)[:,np.newaxis]
    pp.ion()        
    pp.figure()
    pp.pcolor(blockmodel.c/blockmodel.I,cmap=cmap,edgecolors="k")
    pp.xticks(np.arange(blockmodel.K)+.5,np.arange(blockmodel.K)+1)
    pp.yticks(np.arange(blockmodel.K)+.5,np.arange(blockmodel.K)+1)
    pp.colorbar()
    #~ pp.figure()
    #~ pp.pcolor(m/np.sum(m,0)[np.newaxis,:],cmap=cmap)
    #~ pp.colorbar()
    #~ pp.figure()
    #~ pp.pcolor(m/np.sum(m,1)[:,np.newaxis],cmap=cmap)# determines empty positions
    #~ pp.colorbar()
    order = np.argsort(Ytrue)
    Z_hat = Z_hat[order]
    Z = Z[order]
    startclass=0
    pp.figure()
    yticklocs = np.empty(blockmodel.C)
    for c in range(blockmodel.C):
        endclass = startclass+np.sum(Ytrue==c)
        sortcol=np.argmax(np.sum(Z[startclass:endclass,:],0))
        order[startclass:endclass] = startclass + np.argsort(Z_hat[startclass:endclass,:],axis=0)[:,sortcol]
        pp.plot([0,blockmodel.K],[endclass,endclass],"b--",lw=6,alpha=.6)
        yticklocs[c] = startclass+(endclass-startclass)/2.
        startclass=endclass
    Z_hat = Z_hat[order]
    pp.pcolor(Z_hat,cmap=cmap)# determines empty positions
    pp.yticks(yticklocs,yticklabels,fontsize=15)#,rotation=45)
    pp.xticks(np.arange(blockmodel.K)+.5,np.arange(blockmodel.K)+1)
    pp.colorbar()
    #~ make_axes_area_auto_adjustable(pp.gca())
    return np.round(blockmodel.c/blockmodel.I*1000)/1000.

def plotsum(adj,layout="kk",file=None):
    g = iG.Graph.Weighted_Adjacency(adj.tolist())
    visual_style = {}
    visual_style["edge_width"]=4
    visual_style["vertex_label_dist"]=3
    visual_style["vertex_label_size"]=30
    #~ visual_style["edge_width"]=[.2+20*w for w in g.es["weight"]]
    visual_style["edge_color"]=["rgb(%i,%i,%i)" %((220-255*4*w),(220-255*4*w),(255-255*4*w)) for w in g.es["weight"]]
    visual_style["edge_arrow_size"]=[1+3*w for w in g.es["weight"]]
    visual_style["vertex_label"]=range(1,np.shape(adj)[0]+1)
    #~ visual_style["vertex_label"]=yticklabels
    #~ visual_style["vertex_label"]=yts
    print visual_style["vertex_label"]
    visual_style["layout"] = g.layout(layout)
    visual_style["margin"] = 55
    if file:
        iG.plot(g, file, **visual_style)
    else:
        iG.plot(g, **visual_style)

def plotgraph(netfile,classfile,layout="fr"):
    g = iG.Graph.Read_Ncol(netfile)
    c = netio.importClassLabels(classfile)
    g.vs["class"] = [c[int(n)] for n in g.vs["name"]]
    color_dict = {0: "blue", 1: "red"}
    g.vs["color"] = [color_dict[label] for label in g.vs["class"]]
    layout = g.layout(layout)
    iG.plot(g, layout = layout)