import os 


if not os.path.exists('svm_multiclass_learn'):
    print """
        
        Error: No svm package for optimising discriminant function 
        
        Run: "Make" to build package
        
        """ 
    
else:

    import argparse
    import superBM1 as sb


    parser = argparse.ArgumentParser(description="Maximum-margin Blockmodel")
    parser.add_argument("exp", help="The network dataset to use", choices=["karate","word","seafood","seahabit","cora"])
    parser.add_argument("K", help="Number of latent roles", type=int)
    parser.add_argument("Q", help="Selection Method", choices=["random","degree","minmar"])
    parser.add_argument("-nf", "--nodefile", help="Name of file to store order of nodes explored")
    parser.add_argument("-af", "--accfile", help="Name of file to store classification accuracy of unlabelled nodes at each stage")
    args = parser.parse_args()

    e = sb.Experimenter(args.exp,"MED")

    e.params["K"] = args.K
    e.params["reg"] = 50.0
    
    if args.nodefile:
        args.nodefile=open(args.nodefile,"w")
    if args.accfile:
        args.accfile=open(args.accfile,"w")
       
    blockmodel = e.runActiveExp(selectionMethod=args.Q,nodefile=args.nodefile,accfile=args.accfile)

    print "done"
