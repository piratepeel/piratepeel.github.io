import networkx as nx
import numpy as np
#~ import numexpr as ne
from scipy.special import gammaln
from operator import mul
from scipy.optimize import fmin_cg
from sys import stdout
import mlpy

def num(s):
    try:
        return int(s)
    except ValueError:
        try:
            return float(s)
        except ValueError:
            return s

#safe log function
def xlogy(x, y):
    return x*np.log(y+1e-200)


class Supervised_Blockmodel(object):
    def __init__(self, G=None):
        if G is not None:
            self.G=G
        params={}
        with open("params.txt") as file:
            for line in file.read().splitlines():
                items = line.split(":")
                key, values = items[0], items[1].strip()
                params[key] = num(values)
        self.maxiterations=params["maxiterations"]
        self.miniterations=2
        self.convtol = 1e-6
        self.fp_tol = 1e-5
        self.K = params["K"]
        self.alpha = np.ones((self.K,self.K))*params["alpha"]
        self.beta = params["beta"]
        self.disp = bool(params["disp"])
        print self.disp
        self.reg = params["reg"]
        self.N = len(self.G)
        self.I = len(self.G.edges())
        self.initialiseZ()
        #set lookup for classes
        self.cindx_lut={}
        self.cindx_lutr={}
        cindx=0
        for name,node in self.G.node.iteritems():
            if not node.has_key("label"):
                print name,node
                node["label"]=""
            if node["label"]=="":
                node["cindx"] = None
            else:
                if not self.cindx_lut.has_key(node["label"]):
                    self.cindx_lut[node["label"]]=cindx
                    self.cindx_lutr[cindx]=node["label"]
                    cindx+=1
                node["cindx"] = self.cindx_lut[node["label"]]
        self.C = cindx
    
    def infer(self):
        t=0
        self.ELBO = 1
        self.ELBOdiff = 1
        lastt = self.maxiterations
        self.fopt=0
        tt0=0
        for node,v in self.G.nodes_iter(data=True):
            try:
                tt0+=((int(v["label"])-1)==np.argmax((v["nv"])/sum(v["nv"])))
            except ValueError:
                pass
        self.eta_updates=self.N/float(self.I)
        self.eta_counts=self.I
        edgelist = self.G.edges()
        z_entropy = -np.array([np.sum(xlogy(self.G.edge[e[0]][e[1]]["Z"],self.G.edge[e[0]][e[1]]["Z"])) for e in edgelist])
        total_entropy=np.sum(z_entropy)
        #~ eis=np.zeros(self.I)
        order = np.arange(self.I)
        while t < self.maxiterations:
            #~ eis=np.zeros(self.I)
            #~ eta_score=self.eta_updates
            #~ self.eta_updates=0
            #~ iorder = self.getiorder()
            tot = 0
            skip=0
            np.random.shuffle(order)
            #~ for e in self.G.edges_iter() :
            for i,eidx in enumerate(order) :
                stdout.write("********Iteration %i : %i%% \r" %(t,i*100/self.I))
                stdout.flush()
                #~ if t<=self.miniterations:
                #~ eidx=int(np.floor(np.random.rand()*self.I))
                #~ else:
                    #~ eidx=np.argmax(np.random.multinomial(1,z_entropy/total_entropy))
                e=edgelist[eidx]
                #~ self.zthresh=0.999
                #~ if np.max(self.G.edge[e[0]][e[1]]["Z"])>=self.zthresh and t>=self.miniterations:
                    #~ skip+=1
                    #~ self.approxZ(e)
                    #~ self.G.edge[e[0]][e[1]]["Z"]=(self.G.edge[e[0]][e[1]]["Z"]>zthresh)*1
                #~ else:
                    #~ eis[eidx]+=1
                self.updateZ(e)
                    #~ total_entropy-=z_entropy[eidx]
                    #~ z_entropy[eidx]=-np.sum(xlogy(self.G.edge[e[0]][e[1]]["Z"],self.G.edge[e[0]][e[1]]["Z"]))
                    #~ total_entropy+=z_entropy[eidx]
                #~ if t%self.hyper_update_freq==self.hyper_update_freq-1:
                    #~ self.update_alpha()
                    #~ self.update_beta()
                #~ if len(self.tnodes) > 0:
                    #~ anum=np.random.rand()
                    #~ thresh=(self.eta_updates+1)/float(self.eta_counts+2)
                    #~ if anum<thresh or i==0:
            self.update_eta()
                        #~ self.update_eta_old()
            #~ if self.disp:
                #~ self.classify()
                #~ self.validation()
            self.oldELBO = self.ELBO
            self.calculateELBO(t)
            t += 1
            if ((self.ELBOdiff < self.convtol))*(t>self.miniterations):
                lastt = t
                t = self.maxiterations
            #~ print eis
            print skip
        #~ self.disp=True
        #~ self.classify()
        #~ self.validation()
        #~ self.calculateFinalELBO(lastt)
        #~ return self.p_test
        tt=0
        yt=0
        for node in xrange(1,self.N):
            node=str(node)
            v=self.G.node[str(node)]
            #~ print node, "\t", (v["fv"]+v["gv"])/sum(v["fv"]+v["gv"])
        
        #~ for node,v in self.G.nodes_iter(data=True):
        try:
            tt+=((int(v["label"])-1)==np.argmax((v["nv"])/sum(v["nv"])))
            yt+=((self.cindx_lut[v["label"]])==np.argmax(np.exp(np.dot(v["Z_hat"], self.eta))))
        except:
            pass
            #~ print node, "\t", (v["nv"])/sum(v["nv"]), v["label"], tt, np.argmax(np.exp(np.dot(v["Z_hat"], self.eta)))
        print tt0,tt,yt
        self.update_eta()
        for node in xrange(1,self.N):
            node=str(node)
            v=self.G.node[str(node)]
            #~ print node, "\t", (v["fv"]+v["gv"])/sum(v["fv"]+v["gv"])
            try:
        #~ for node,v in self.G.nodes_iter(data=True):
                tt+=((int(v["label"])-1)==np.argmax((v["nv"])/sum(v["nv"])))
                yt+=((self.cindx_lut[v["label"]])==np.argmax(np.exp(np.dot(v["Z_hat"], self.eta))))
            except:
                pass
            #~ print node, "\t", (v["nv"])/sum(v["nv"]), v["label"], tt, np.argmax(np.exp(np.dot(v["Z_hat"], self.eta)))
        print tt0,tt,yt
        self.predict()

class MixedMembership(Supervised_Blockmodel):
    def __init__(self, G=None):
        print len(G)
        super(MixedMembership, self).__init__(G)
        self.etamaxiter = 1
        self.G.graph["sum_nv"]=np.zeros(self.K)
        for node,nodeData in self.G.nodes_iter(data=True):
            fv= np.array(sum(v["Zs"] for v in self.G.succ[node].itervalues()))
            gv= np.array(sum(v["Zr"] for v in self.G.pred[node].itervalues()))
            nodeData["nv"]=fv+gv
            self.G.graph["sum_nv"]+=nodeData["nv"]
        self.G.graph["sum_nv"]+=self.N*self.beta
        self.eta = np.random.randn(self.K,self.C)*self.reg + np.eye(self.K,self.C)
        self.getnormh()
    
    def initialiseZ(self):
        K2 = self.K*self.K
        self.G.graph["c"]=np.zeros(np.shape(self.alpha))
        for link in self.G.edges_iter(data=True):
            edge=link[2]
            edge["Z"]=np.random.mtrand.dirichlet(self.alpha.flatten()).reshape(self.K,self.K)
            Z=edge["Z"]
            edge["Zs"]=np.sum(Z,1)
            edge["Zr"]=np.sum(Z,0)
            self.G.graph["c"]+=Z
    
    
    def calculateELBO(self,t):
        self.ELBO = -self.fopt + np.sum(self.eta*self.eta*self.reg/2.)
        self.ELBO += gammaln(np.sum(self.alpha)) - np.sum(gammaln(self.alpha))
        self.ELBO += np.sum(gammaln(self.G.graph["c"]+self.alpha)) - gammaln(np.sum(self.G.graph["c"]+self.alpha))
        
        self.ELBO += self.K*(gammaln(self.beta*self.N) - gammaln(self.beta)*self.K*self.N)
        self.ELBO += sum(sum(gammaln(v["nv"]+self.beta) for node,v in self.G.nodes_iter(data=True)))
        self.ELBO -= np.sum(gammaln(self.G.graph["sum_nv"]+self.N*self.beta))
        
        
        self.ELBO -= np.sum(sum(xlogy(edge[2]["Z"],edge[2]["Z"]) for edge in self.G.edges_iter(data=True)))
        self.ELBOdiff = np.abs((self.ELBO-self.oldELBO))
        #~ self.ELBOdiff = (self.ELBO-self.oldELBO)
        update="***"
        if self.disp:
            #~ print " f1=%.2f(%.2f) acc=%.2f(%.2f)  t,self.f1_tr,self.f1_te,self.p_train, self.p_test, )
            print "%i:ELBO = %f  ELBO diff = %f \t eta update prob %f" % (t,self.ELBO, self.ELBOdiff,(self.eta_updates/float(self.eta_counts)))
    
    
    def updateZ(self,link):
        
        #remove counts including current node v
        G=self.G
        s=G.node[link[0]]
        r=G.node[link[1]]
        edge=G.edge[link[0]][link[1]]
        #~ print edge["Zr"]
        zs=edge["Zs"]
        zr=edge["Zr"]
        z=edge["Z"]
        
        #~ elbo=np.sum(gammaln(self.G.graph["c"])) + np.sum(gammaln(s["nv"])) + np.sum(gammaln(r["nv"])) - 2*np.sum(gammaln(self.G.graph["sum_nv"])) - np.sum(xlogy(z,z))
        
        G.graph["c"] -= z
        
        s["nv"] -= zs
        r["nv"] -= zr
        G.graph["sum_nv"]-=zs
        G.graph["sum_nv"]-=zr
        
        z_v = (G.graph["c"]+self.alpha)*np.dot((s["nv"]+self.beta)[:,np.newaxis],(r["nv"] +self.beta)[np.newaxis,:]) 
        z_v /= (np.dot(G.graph["sum_nv"][:,np.newaxis],G.graph["sum_nv"][np.newaxis,:]) + np.eye(self.K))
        
        
        ys = s["cindx"]
        yr = r["cindx"]
        
        if ys is not None:
            expetaNs = self.exp_etaNv[self.G.degree()[link[0]]]
            expetaNsy = expetaNs[:,ys]
            z_v*=expetaNsy[:,np.newaxis]
        if yr is not None:
            expetaNr = self.exp_etaNv[self.G.degree()[link[1]]]
            expetaNry = expetaNr[:,yr]
            z_v*=expetaNry[np.newaxis,:]
        
        
        
        fp = 1
        newZi = np.copy(z)
        hnorm_si = np.copy(s["hnorm"])
        hnorm_ri = np.copy(r["hnorm"])
        while fp > self.fp_tol: 
            oldZi = np.copy(newZi)
            newZi = np.copy(z_v)
            if ys is not None:
                hsdotz = np.sum(hnorm_si)
                hnorm_si /= np.dot(zs,expetaNs)
                hs = np.sum(expetaNs * hnorm_si, 1)
                newZi *= np.exp(-(hs/hsdotz)[:,np.newaxis])
            if yr is not None:
                hrdotz = np.sum(hnorm_ri)
                hnorm_ri /= np.dot(zr,expetaNr)
                hr = np.sum(expetaNr * hnorm_ri, 1)
                newZi *= np.exp(-(hr/hrdotz)[np.newaxis,:])
            
            newZi /= np.sum(newZi)
            newZi[newZi<0.001]=0
            newZi /= np.sum(newZi)
            
            zs = np.sum(newZi,1)
            zr = np.sum(newZi,0)
            
            if ys is not None:
                hnorm_si *= np.dot(zs,expetaNs)
            if yr is not None:
                hnorm_ri *= np.dot(zr,expetaNr)
            
            fp = np.sum(np.abs(oldZi - newZi))/(self.K*self.K)
        
        s["hnorm"] = hnorm_si
        r["hnorm"] = hnorm_ri
        
        edge["Zs"]=zs
        edge["Zr"]=zr
        edge["Z"]=newZi
        self.G.graph["sum_nv"]+=zr
        self.G.graph["sum_nv"]+=zs
        s["nv"] += zs
        r["nv"] += zr
        G.graph["c"] += newZi
    
    def getnormh(self):
        self.hnorm = {}
        degrees=self.G.degree()
        uniqueDegrees=np.unique(degrees.values())
        #cache values for e^(\eta/d)
        exp_etaNv = dict((d,np.exp(self.eta/d)) for d in uniqueDegrees)
        C=self.C
        Cones=np.ones(C)
        for node,nodeData in self.G.nodes_iter(data=True):
            expetaN = exp_etaNv[degrees[node]]
            nodeData["hnorm"] = Cones
            nodeData["hnorm"] = reduce(mul,(np.dot(v["Zs"],expetaN) for v in self.G.succ[node].itervalues()),nodeData["hnorm"]) 
            nodeData["hnorm"] = reduce(mul,(np.dot(v["Zr"],expetaN) for v in self.G.pred[node].itervalues()),nodeData["hnorm"])
        self.exp_etaNv = exp_etaNv
        
    def update_eta(self):
        
        eta_prime = np.zeros((self.K,self.C))
        for node,nodeData in self.G.nodes_iter(data=True):
            d = self.G.degree()[node]
            nodeData["Z_hat"] = sum(v["Zs"] for v in self.G.succ[node].itervalues()) / d    ##change:update z_hat with update z?
            nodeData["Z_hat"] += sum(v["Zr"] for v in self.G.pred[node].itervalues()) / d
            if nodeData["cindx"] is not None:
                eta_prime[:,nodeData["cindx"]] += nodeData["Z_hat"]
        
        self.eta_prime=eta_prime
        
        eta = self.eta.reshape(self.eta.size)
        fopt_b = self.L_eta(eta)
        eta, fopt, func_calls, grad_calls, warnflag = fmin_cg(self.L_eta, eta, self.L_eta_prime, maxiter=self.etamaxiter, disp=0,full_output=1)
        
        #only accept changes that improve ELBO
        if (fopt_b-fopt)>self.fp_tol or self.fopt<=0:
            self.eta = eta.reshape(self.K, self.C)
            self.fopt = fopt
            self.getnormh()
        else:
            self.fopt=fopt_b
        self.etamaxiter = 1
        #~ self.etamaxiter = np.min([30,self.etamaxiter+1])

    
    def L_eta(self, eta) :
        
        L_eta = 0
        eta = eta.reshape(self.K, self.C)
        
        degrees=self.G.degree()
        uniqueDegrees=np.unique(degrees.values())
        #cache values for e^(\eta/d)
        exp_etaNv = dict((d,np.exp(eta/d)) for d in uniqueDegrees) 
        Cones=np.ones(self.C)
        for node,nodeData in self.G.nodes_iter(data=True):
            y = nodeData["cindx"]
            if y is not None:
                expetaN = exp_etaNv[degrees[node]]
                L_eta += np.dot(nodeData["Z_hat"],eta[:,y])
                sCones=Cones
                rCones=Cones
                L_eta += -xlogy(1.0,np.sum(reduce(mul,(np.dot(v["Zs"],expetaN) for v in self.G.succ[node].itervalues()),sCones) * reduce(mul,(np.dot(v["Zr"],expetaN) for v in self.G.pred[node].itervalues()),rCones) ))
        #~ print "L_eta", L_eta
        return -(L_eta - np.sum(eta*eta*self.reg/2.))
        

    def L_eta_prime(self, eta) :
        
        K = self.K
        C = self.C
        
        eta = eta.reshape(K, C)
        L_eta_prime = np.zeros((K,C))
        
        degrees=self.G.degree()
        uniqueDegrees=np.unique(degrees.values())
        exp_etaNv = dict((d,np.exp(eta/d)) for d in uniqueDegrees)
        
        
        for node,nodeData in self.G.nodes_iter(data=True):
            y = nodeData["cindx"]
            if y is not None:
                d = degrees[node]
                expetaN = exp_etaNv[d]
                
            
                z1s = np.array([v["Zs"] for v in self.G.succ[node].itervalues()])
                z2r = np.array([v["Zr"] for v in self.G.pred[node].itervalues()])
                
                #c_level dims: 1 x C
                #catch instances where there is no in- or out- degree
                try:
                    c_level = np.prod(np.dot(z1s,expetaN), 0) #u
                    #this_k_levels dims: ns x k2 x C
                    this_k_levels = z1s[:,:,np.newaxis] * expetaN#w
                    this_k_levels /= (d * np.sum(this_k_levels,1)[:,np.newaxis,:])#x
                except ValueError:
                    this_k_levels=0
                    try:
                        c_level = np.prod(np.dot(z2r,expetaN), 0)
                        this_k_levelr = z2r[:,:,np.newaxis] * expetaN#w
                        this_k_levelr /= (d * np.sum(this_k_levelr,1)[:,np.newaxis,:])#x
                    except ValueError:
                        c_level = np.zeros(C)
                        this_k_levelr=0
                else:
                    try:
                        c_level*= np.prod(np.dot(z2r,expetaN), 0)
                        this_k_levelr = z2r[:,:,np.newaxis] * expetaN#w
                        this_k_levelr /= (d * np.sum(this_k_levelr,1)[:,np.newaxis,:])#x
                    except ValueError:
                        this_k_levelr=0
                c_level /= np.sum(c_level)#v
            
                
                
                L_eta_prime += -c_level.reshape(1,C) * (np.sum(this_k_levels,0) + np.sum(this_k_levelr,0))
            
        L_eta_prime -= self.reg*eta
        return -(self.eta_prime+L_eta_prime).reshape(L_eta_prime.size)
        
    def predict(self):
        for node,v in self.G.nodes_iter(data=True):
            v["prediction"]=self.cindx_lutr[np.argmax(np.exp(np.dot(v["Z_hat"], self.eta)))]

    def classify(self) :
        probs = np.empty((self.N,self.C))
        z1 = self.Z1
        z2 = self.Z2
        S = self.S
        R = self.R
        nv = self.nv
        eta = self.eta
        sidxs = self.sidxs
        ridxs = self.ridxs
        K=self.K
        z_hat = np.empty(2*K)
        for v in range(self.N) :
            z_hat[:K] = np.sum(z1[sidxs[v],:],0) / float(nv[v])
            z_hat[K:] = np.sum(z2[ridxs[v],:],0) / float(nv[v])
            probs[v,:] = np.exp(np.dot(z_hat, eta))
            probs[v,:] /= np.sum(probs[v,:])
        self.probs = probs
        self.predictions = probs.argmax(1)
    
    ###################################################
    
    
    def update_alpha(self) :
        I = self.I
        alpha_new = self.alpha
        Z = self.Z
        diff=1
        i=0
        while diff>1e-6:
            alpha=alpha_new
            sum_alpha = np.sum(alpha)
            alpha_new = alpha*(np.sum(psi(Z+alpha[np.newaxis,:,:]),0) - I*psi(alpha))/(I*psi(1 + sum_alpha) - I*psi(sum_alpha))
            diff = np.sum(np.abs(alpha_new-alpha))/(self.K*self.K)
            i+=1
            if i>100:
                diff=0
        self.alpha = alpha_new
        

    def classify(self) :
        probs = np.empty((self.N,self.C))
        z1 = self.Z1
        z2 = self.Z2
        S = self.S
        R = self.R
        nv = self.nv
        eta = self.eta
        sidxs = self.sidxs
        ridxs = self.ridxs
        
        for v in range(self.N) :
            z_hat = (np.sum(z1[sidxs[v],:],0) + np.sum(z2[ridxs[v],:],0)) / float(nv[v])
            probs[v,:] = np.exp(np.dot(z_hat, eta))
            probs[v,:] /= np.sum(probs[v,:])
        self.probs = probs
        self.predictions = probs.argmax(1)
        



if __name__=="__main__":
    print "supervisedBM v0.3"
    import argparse
    parser = argparse.ArgumentParser()
    networkfiletype = parser.add_mutually_exclusive_group()
    networkfiletype.add_argument("-a", "--adjlist", action="store_true", help="adjacency list network format (default)")
    networkfiletype.add_argument("-q", "--quiet", action="store_true")
    parser.add_argument("networkfile", help="Input network file")
    parser.add_argument("-c","--classlist", help="File of class labels list")
    parser.add_argument("-o","--outputFile", help="Output File")
    args = parser.parse_args()
    
    if args.adjlist:
        inG = nx.read_adjlist(args.networkfile, create_using=nx.DiGraph())
    else:
        pass
    if args.classlist:
        with open(args.classlist) as f:
            labels = f.readlines()
        for label in labels:
            v,l = label.split()
            inG.node[v]["label"]=l.strip()
        #~ if len(inG)==len(labels):
            #~ for i,label in enumerate(labels):
                #~ inG.node[str(i+1)]["label"] = label.strip()
                #~ inG.node[str(i)]["label"] = label.strip()
        #~ else:
            #~ print "Error: Label number mismatch %i != %i" % (len(inG),len(labels))
    
    #~ print G.node
    sb = MixedMembership(inG)
    sb.infer()
    if args.outputFile:
        with open(args.outputFile,"w") as f:
            for node,v in sb.G.nodes_iter(data=True):
                f.write("%s\t%s\n" % (str(node),str(v["prediction"])))